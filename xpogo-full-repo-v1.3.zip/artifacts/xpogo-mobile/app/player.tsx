import { useState, useEffect, useCallback, useRef } from "react";
import { useLocalSearchParams, useRouter } from "expo-router";
import {
  View, StyleSheet, TouchableOpacity, Text,
  StatusBar, ActivityIndicator, Dimensions, ScrollView,
  BackHandler,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import WebView from "react-native-webview";
import * as ScreenOrientation from "expo-screen-orientation";

const FALLBACK = "b30fc0f2-ea8a-424a-88ee-fa02e53bd00a-00-1n14z61p3qun8.pike.replit.dev";
const API_URL = `https://${process.env.EXPO_PUBLIC_DOMAIN || FALLBACK}`;

const BG = "#0d1117";
const CARD_BG = "#1a2332";
const GREEN = "#00c853";
const GRAY = "#8a9bb0";

interface EmbedRecord {
  id: string; title: string; url: string;
  type: string; active: boolean; tmdbId?: number; sub?: string;
}

interface ServerItem {
  id: string; label: string; url: string;
  badge: string; badgeColor: string; icon: string; sub?: string;
}

function buildZxcMovieUrl(id: number, serverNum: number) {
  return `https://zxcstream.xyz/player/movie/${id}?server=${serverNum}&color=00c853&autoplay=true&back=true`;
}
function buildZxcTvUrl(id: number, serverNum: number, season: number, episode: number) {
  return `https://zxcstream.xyz/player/tv/${id}?server=${serverNum}&color=00c853&autoplay=true&back=true&season=${season}&episode=${episode}`;
}

export default function PlayerScreen() {
  const params = useLocalSearchParams<{
    url: string; title?: string;
    tmdbId?: string; mediaType?: string;
    season?: string; episode?: string;
  }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [activeUrl, setActiveUrl] = useState(params.url ? decodeURIComponent(params.url) : "");
  const [loading, setLoading] = useState(true);
  const [fullscreen, setFullscreen] = useState(false);
  const [screenSize, setScreenSize] = useState(Dimensions.get("window"));
  const [servers, setServers] = useState<ServerItem[]>([]);
  const [loadingServers, setLoadingServers] = useState(false);

  const tmdbId = params.tmdbId ? Number(params.tmdbId) : null;
  const mediaType = params.mediaType ?? "movie";
  const season = params.season ? Number(params.season) : 1;
  const episode = params.episode ? Number(params.episode) : 1;
  const title = params.title ? decodeURIComponent(params.title) : "";

  /* ── Listen dimension changes (landscape/portrait) ── */
  useEffect(() => {
    const sub = Dimensions.addEventListener("change", ({ window }) => {
      setScreenSize(window);
    });
    return () => sub?.remove();
  }, []);

  /* ── Fullscreen: lock landscape / unlock on exit ── */
  const enterFullscreen = useCallback(async () => {
    await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE);
    setFullscreen(true);
  }, []);

  const exitFullscreen = useCallback(async () => {
    await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    setFullscreen(false);
  }, []);

  /* ── Back button exits fullscreen first ── */
  useEffect(() => {
    const handler = BackHandler.addEventListener("hardwareBackPress", () => {
      if (fullscreen) {
        exitFullscreen();
        return true;
      }
      return false;
    });
    return () => handler.remove();
  }, [fullscreen, exitFullscreen]);

  /* ── Unlock orientation when leaving screen ── */
  useEffect(() => {
    return () => {
      ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    };
  }, []);

  const buildServers = useCallback((embeds: EmbedRecord[]): ServerItem[] => {
    const list: ServerItem[] = [];
    if (!tmdbId) return list;
    if (mediaType === "movie") {
      list.push(
        { id: "s1", label: "Server 1 — Utama", url: buildZxcMovieUrl(tmdbId, 1), badge: "HD", badgeColor: GREEN, icon: "🖥️" },
        { id: "s2", label: "Server 2", url: buildZxcMovieUrl(tmdbId, 2), badge: "HD", badgeColor: "#3b82f6", icon: "🖥️" },
        { id: "s3", label: "Server 3", url: buildZxcMovieUrl(tmdbId, 3), badge: "ALT", badgeColor: "#8b5cf6", icon: "🖥️" },
      );
    } else {
      list.push(
        { id: "s1", label: "Server 1 — Utama", url: buildZxcTvUrl(tmdbId, 1, season, episode), badge: "HD", badgeColor: GREEN, icon: "🖥️" },
        { id: "s2", label: "Server 2", url: buildZxcTvUrl(tmdbId, 2, season, episode), badge: "HD", badgeColor: "#3b82f6", icon: "🖥️" },
        { id: "s3", label: "Server 3", url: buildZxcTvUrl(tmdbId, 3, season, episode), badge: "ALT", badgeColor: "#8b5cf6", icon: "🖥️" },
      );
    }
    embeds.forEach((e, i) => {
      list.push({
        id: e.id, label: e.title || `Embed ${i + 1}`,
        url: e.url, badge: "EMBED", badgeColor: "#f59e0b", icon: "📡",
        sub: e.sub ? `Sub: ${e.sub}` : undefined,
      });
    });
    return list;
  }, [tmdbId, mediaType, season, episode]);

  useEffect(() => {
    if (!tmdbId) return;
    setLoadingServers(true);
    fetch(`${API_URL}/api/embeds`)
      .then(r => r.json())
      .then((list: EmbedRecord[]) => {
        if (!Array.isArray(list)) { setServers(buildServers([])); return; }
        const matched = list.filter(e =>
          e.active && e.tmdbId === tmdbId &&
          (mediaType === "movie" ? e.type === "movie" : e.type === "series")
        );
        setServers(buildServers(matched));
      })
      .catch(() => setServers(buildServers([])))
      .finally(() => setLoadingServers(false));
  }, [tmdbId, mediaType, season, episode, buildServers]);

  /* ── FULLSCREEN MODE ── */
  if (fullscreen) {
    const fsW = screenSize.width;
    const fsH = screenSize.height;
    return (
      <View style={{ flex: 1, backgroundColor: "#000" }}>
        <StatusBar hidden />
        <WebView
          source={{ uri: activeUrl }}
          style={{ width: fsW, height: fsH, backgroundColor: "#000" }}
          allowsFullscreenVideo
          allowsInlineMediaPlayback
          mediaPlaybackRequiresUserAction={false}
          javaScriptEnabled
          domStorageEnabled
          originWhitelist={["*"]}
        />
        <TouchableOpacity
          style={S.exitFsBtn}
          onPress={exitFullscreen}
          activeOpacity={0.8}
        >
          <Text style={S.exitFsText}>⤡ Keluar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  /* ── NORMAL MODE ── */
  const PLAYER_H = screenSize.width * (9 / 16);

  if (!activeUrl) {
    return (
      <View style={[S.container, { paddingTop: insets.top }]}>
        <TouchableOpacity style={S.backBtn} onPress={() => router.back()} activeOpacity={0.8}>
          <Text style={S.backText}>✕ Kembali</Text>
        </TouchableOpacity>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <Text style={{ color: GRAY, fontSize: 14 }}>URL tidak ditemukan.</Text>
        </View>
      </View>
    );
  }

  const isActive = (sv: ServerItem) => sv.url === activeUrl;

  return (
    <View style={S.container}>
      <StatusBar barStyle="light-content" backgroundColor={BG} translucent={false} />

      {/* TOP BAR */}
      <View style={[S.topBar, { paddingTop: insets.top + 6 }]}>
        <TouchableOpacity style={S.backBtn} onPress={() => router.back()} activeOpacity={0.8}>
          <Text style={S.backText}>‹ Kembali</Text>
        </TouchableOpacity>
        <TouchableOpacity style={S.fsBtn} onPress={enterFullscreen} activeOpacity={0.8}>
          <Text style={S.fsBtnText}>⛶ Layar Penuh</Text>
        </TouchableOpacity>
      </View>

      {/* PLAYER BOX — 16:9 */}
      <View style={[S.playerBox, { height: PLAYER_H }]}>
        {loading && (
          <View style={S.loadingOverlay}>
            <ActivityIndicator color={GREEN} size="large" />
            <Text style={{ color: GRAY, marginTop: 12, fontSize: 13 }}>Memuat player...</Text>
          </View>
        )}
        <WebView
          key={activeUrl}
          source={{ uri: activeUrl }}
          style={S.webview}
          allowsFullscreenVideo
          allowsInlineMediaPlayback
          mediaPlaybackRequiresUserAction={false}
          javaScriptEnabled
          domStorageEnabled
          originWhitelist={["*"]}
          onLoadStart={() => setLoading(true)}
          onLoadEnd={() => setLoading(false)}
          onError={() => setLoading(false)}
        />
      </View>

      {/* INFO + SERVER LIST */}
      <ScrollView
        style={S.infoScroll}
        contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 40 }}
        showsVerticalScrollIndicator={false}
      >
        {!!title && <Text style={S.titleText} numberOfLines={2}>{title}</Text>}

        {mediaType !== "movie" && (
          <View style={S.epBadgeRow}>
            <View style={S.epBadge}>
              <Text style={S.epBadgeText}>S{season} E{episode}</Text>
            </View>
            <Text style={{ color: GRAY, fontSize: 12, marginLeft: 8 }}>Sedang diputar</Text>
          </View>
        )}

        <View style={S.sectionHeader}>
          <Text style={S.sectionTitle}>🖥️  Pilih Server</Text>
          {loadingServers && <ActivityIndicator color={GREEN} size="small" style={{ marginLeft: 8 }} />}
        </View>

        {servers.length === 0 && !loadingServers ? (
          <View style={S.infoCard}>
            <Text style={S.infoCardBody}>
              Tidak ada server tersedia. Kembali ke halaman detail untuk memilih server.
            </Text>
          </View>
        ) : (
          <View style={S.serverList}>
            {servers.map((sv) => {
              const active = isActive(sv);
              return (
                <TouchableOpacity
                  key={sv.id}
                  style={[S.serverRow, active && S.serverRowActive]}
                  onPress={() => { if (!active) { setActiveUrl(sv.url); setLoading(true); } }}
                  activeOpacity={0.75}
                >
                  <View style={S.serverIcon}>
                    <Text style={{ fontSize: 18 }}>{sv.icon}</Text>
                  </View>
                  <View style={{ flex: 1, marginLeft: 10 }}>
                    <Text style={[S.serverLabel, active && { color: GREEN }]} numberOfLines={1}>
                      {sv.label}
                    </Text>
                    {sv.sub ? <Text style={S.serverSub}>{sv.sub}</Text> : null}
                  </View>
                  <View style={[S.badge, { backgroundColor: sv.badgeColor + "22", borderColor: sv.badgeColor }]}>
                    <Text style={[S.badgeText, { color: sv.badgeColor }]}>{sv.badge}</Text>
                  </View>
                  {active && <View style={S.activeDot} />}
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        <View style={[S.infoCard, { marginTop: 14 }]}>
          <Text style={S.infoCardTitle}>💡 Tips</Text>
          <Text style={S.infoCardBody}>
            Tap <Text style={{ color: GREEN, fontWeight: "700" }}>Layar Penuh</Text> untuk rotate landscape otomatis. Tekan tombol Back HP untuk keluar fullscreen.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const S = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  topBar: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 14, paddingBottom: 8, backgroundColor: BG,
  },
  backBtn: {
    flexDirection: "row", alignItems: "center",
    backgroundColor: CARD_BG, borderRadius: 20,
    paddingHorizontal: 14, paddingVertical: 7,
  },
  backText: { color: "#fff", fontSize: 14, fontWeight: "700" },
  fsBtn: {
    backgroundColor: "#0a3d1f", borderRadius: 20, borderWidth: 1, borderColor: GREEN,
    paddingHorizontal: 14, paddingVertical: 7,
  },
  fsBtnText: { color: GREEN, fontSize: 13, fontWeight: "700" },
  playerBox: { width: "100%", backgroundColor: "#000", position: "relative" },
  webview: { flex: 1, backgroundColor: "#000" },
  loadingOverlay: {
    position: "absolute", top: 0, left: 0, right: 0, bottom: 0, zIndex: 10,
    backgroundColor: "#000", alignItems: "center", justifyContent: "center",
  },
  infoScroll: { flex: 1, backgroundColor: BG },
  titleText: { color: "#fff", fontSize: 17, fontWeight: "900", lineHeight: 23, marginBottom: 10 },
  epBadgeRow: { flexDirection: "row", alignItems: "center", marginBottom: 12 },
  epBadge: {
    backgroundColor: GREEN + "22", borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1, borderColor: GREEN,
  },
  epBadgeText: { color: GREEN, fontSize: 12, fontWeight: "800" },
  sectionHeader: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  sectionTitle: { color: "#fff", fontSize: 14, fontWeight: "800" },
  serverList: { gap: 8 },
  serverRow: {
    flexDirection: "row", alignItems: "center",
    backgroundColor: CARD_BG, borderRadius: 14,
    padding: 13, borderWidth: 1.5, borderColor: "#2a3a4a",
  },
  serverRowActive: { borderColor: GREEN, backgroundColor: "#0a1f10" },
  serverIcon: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: "#0d1a28", alignItems: "center", justifyContent: "center",
  },
  serverLabel: { color: "#fff", fontSize: 13, fontWeight: "700" },
  serverSub: { color: GRAY, fontSize: 11, marginTop: 2 },
  badge: { borderRadius: 6, borderWidth: 1, paddingHorizontal: 7, paddingVertical: 3, marginLeft: 8 },
  badgeText: { fontSize: 10, fontWeight: "800" },
  activeDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: GREEN, marginLeft: 8 },
  infoCard: {
    backgroundColor: CARD_BG, borderRadius: 14,
    padding: 14, borderLeftWidth: 3, borderLeftColor: GREEN,
  },
  infoCardTitle: { color: "#fff", fontWeight: "800", fontSize: 13, marginBottom: 6 },
  infoCardBody: { color: GRAY, fontSize: 13, lineHeight: 19 },
  exitFsBtn: {
    position: "absolute", top: 16, right: 16,
    backgroundColor: "rgba(0,0,0,0.75)", borderRadius: 20,
    paddingHorizontal: 18, paddingVertical: 9,
    borderWidth: 1, borderColor: "rgba(255,255,255,0.25)",
  },
  exitFsText: { color: "#fff", fontWeight: "700", fontSize: 13 },
});
