import { useState } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet, Modal,
  TouchableWithoutFeedback, Share, Linking, Alert,
  ScrollView, Image, ActivityIndicator,
} from "react-native";
import * as Clipboard from "expo-clipboard";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";

const BG = "#0d1117";
const CARD_BG = "#1a2332";
const GREEN = "#00c853";
const GRAY = "#8a9bb0";

const WEB_DOMAIN = process.env.EXPO_PUBLIC_DOMAIN || "b30fc0f2-ea8a-424a-88ee-fa02e53bd00a-00-1n14z61p3qun8.pike.replit.dev";

interface Props {
  visible: boolean;
  onClose: () => void;
  title: string;
  year?: string;
  overview?: string;
  posterUrl?: string;
  tmdbId: number;
  mediaType: "movie" | "tv";
}

export default function ShareSheet({ visible, onClose, title, year, overview, posterUrl, tmdbId, mediaType }: Props) {
  const [sharingPoster, setSharingPoster] = useState(false);
  const [copied, setCopied] = useState(false);

  const webUrl = `https://${WEB_DOMAIN}/${mediaType}/${tmdbId}`;
  const shareText = `🎬 *${title}*${year ? ` (${year})` : ""}\n${overview ? overview.slice(0, 120) + "..." : ""}\n\n📲 Tonton di XpoGo:\n${webUrl}`;

  const copyLink = async () => {
    await Clipboard.setStringAsync(webUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const nativeShare = async () => {
    try {
      await Share.share({ message: shareText, title: `XpoGo — ${title}` });
    } catch { /* user dismissed */ }
  };

  const openWhatsApp = async () => {
    const url = `whatsapp://send?text=${encodeURIComponent(shareText)}`;
    const can = await Linking.canOpenURL(url);
    if (can) await Linking.openURL(url);
    else {
      const web = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
      await Linking.openURL(web);
    }
  };

  const openTelegram = async () => {
    const url = `tg://msg?text=${encodeURIComponent(shareText)}`;
    const can = await Linking.canOpenURL(url);
    if (can) await Linking.openURL(url);
    else await Linking.openURL(`https://t.me/share/url?url=${encodeURIComponent(webUrl)}&text=${encodeURIComponent(`🎬 ${title}`)}`);
  };

  const openFacebook = async () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(webUrl)}`;
    await Linking.openURL(url);
  };

  const sharePosterToInstagram = async () => {
    if (!posterUrl) { Alert.alert("Poster tidak tersedia"); return; }
    setSharingPoster(true);
    try {
      const fileUri = `${FileSystem.cacheDirectory}xpogo_poster_${tmdbId}.jpg`;
      const { status } = await FileSystem.downloadAsync(posterUrl, fileUri);
      if (status !== 200) throw new Error("Download gagal");
      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(fileUri, {
          mimeType: "image/jpeg",
          dialogTitle: `Bagikan poster ${title}`,
        });
      } else {
        Alert.alert("Tidak tersedia", "Fitur berbagi file tidak tersedia di perangkat ini.");
      }
    } catch (e) {
      Alert.alert("Gagal", "Tidak bisa mengunduh poster. Coba lagi.");
    } finally {
      setSharingPoster(false);
    }
  };

  const PLATFORMS = [
    { id: "copy", icon: copied ? "✅" : "🔗", label: copied ? "Tersalin!" : "Salin Link", color: "#2a3a4a", onPress: copyLink },
    { id: "share", icon: "📤", label: "Bagikan", color: "#374151", onPress: nativeShare },
    { id: "wa", icon: "💬", label: "WhatsApp", color: "#075e54", onPress: openWhatsApp },
    { id: "tg", icon: "✈️", label: "Telegram", color: "#0088cc", onPress: openTelegram },
    { id: "fb", icon: "📘", label: "Facebook", color: "#1877f2", onPress: openFacebook },
    { id: "poster", icon: "🖼️", label: "Poster", color: "#7c3aed", onPress: sharePosterToInstagram },
  ];

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <TouchableWithoutFeedback onPress={onClose}>
        <View style={S.overlay}>
          <TouchableWithoutFeedback>
            <View style={S.sheet}>
              <View style={S.handle} />

              {/* JUDUL + POSTER */}
              <View style={S.header}>
                {posterUrl ? (
                  <Image source={{ uri: posterUrl }} style={S.poster} />
                ) : (
                  <View style={[S.poster, { backgroundColor: CARD_BG, alignItems: "center", justifyContent: "center" }]}>
                    <Text style={{ fontSize: 24 }}>🎬</Text>
                  </View>
                )}
                <View style={{ flex: 1 }}>
                  <Text style={S.movieTitle} numberOfLines={2}>{title}</Text>
                  {year && <Text style={S.movieYear}>{year}</Text>}
                  <Text style={S.sheetLabel}>Bagikan ke:</Text>
                </View>
              </View>

              {/* PLATFORM BUTTONS */}
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={S.platforms}>
                {PLATFORMS.map(p => (
                  <TouchableOpacity
                    key={p.id}
                    style={[S.platformBtn, { backgroundColor: p.color }]}
                    onPress={p.onPress}
                    activeOpacity={0.8}
                    disabled={p.id === "poster" && sharingPoster}
                  >
                    {p.id === "poster" && sharingPoster
                      ? <ActivityIndicator color="#fff" size="small" />
                      : <Text style={S.platformIcon}>{p.icon}</Text>
                    }
                    <Text style={S.platformLabel}>{p.label}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              {/* PREVIEW LINK */}
              <View style={S.linkPreview}>
                <Text style={S.linkText} numberOfLines={1}>{webUrl}</Text>
              </View>

              <TouchableOpacity style={S.closeBtn} onPress={onClose} activeOpacity={0.8}>
                <Text style={S.closeBtnText}>Tutup</Text>
              </TouchableOpacity>
            </View>
          </TouchableWithoutFeedback>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
}

const S = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "flex-end" },
  sheet: { backgroundColor: "#111d2e", borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: 12, paddingHorizontal: 20, paddingBottom: 32, borderTopWidth: 1, borderColor: "#2a3a4a" },
  handle: { width: 40, height: 4, backgroundColor: "#2a3a4a", borderRadius: 2, alignSelf: "center", marginBottom: 20 },

  header: { flexDirection: "row", gap: 14, marginBottom: 20, alignItems: "center" },
  poster: { width: 60, height: 90, borderRadius: 10, backgroundColor: CARD_BG },
  movieTitle: { color: "#fff", fontSize: 16, fontWeight: "800", lineHeight: 22, marginBottom: 4 },
  movieYear: { color: GRAY, fontSize: 13, marginBottom: 8 },
  sheetLabel: { color: GRAY, fontSize: 12, fontWeight: "600", textTransform: "uppercase", letterSpacing: 0.8 },

  platforms: { gap: 10, paddingVertical: 4, paddingHorizontal: 2 },
  platformBtn: { width: 72, paddingVertical: 14, borderRadius: 16, alignItems: "center", gap: 6 },
  platformIcon: { fontSize: 24 },
  platformLabel: { color: "#fff", fontSize: 11, fontWeight: "700", textAlign: "center" },

  linkPreview: { backgroundColor: BG, borderRadius: 10, padding: 12, marginTop: 16, borderWidth: 1, borderColor: "#2a3a4a" },
  linkText: { color: GRAY, fontSize: 12 },

  closeBtn: { marginTop: 14, backgroundColor: CARD_BG, borderRadius: 12, paddingVertical: 14, alignItems: "center" },
  closeBtnText: { color: "#fff", fontWeight: "700", fontSize: 15 },
});
