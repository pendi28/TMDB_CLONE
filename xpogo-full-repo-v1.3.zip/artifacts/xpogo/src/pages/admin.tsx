import { useState, useEffect, useRef } from "react";
import {
  useAdminLogin, useAdminVerify, useGetSettings, useUpdateSettings,
  useGetAds, useCreateAd, useUpdateAd, useDeleteAd,
  useGetEmbeds, useCreateEmbed, useUpdateEmbed, useDeleteEmbed,
  useGetCustomMovies, useCreateCustomMovie, useDeleteCustomMovie,
  setAuthTokenGetter,
} from "@workspace/api-client-react";
import { getToken, setToken, clearToken } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";
import {
  Settings, Megaphone, Film, Link2, LogOut, Plus, Trash2,
  Eye, EyeOff, Save, Lock, Tv, Pencil, Search, Check, X, Loader2,
} from "lucide-react";

setAuthTokenGetter(() => getToken());

const IMG = "https://image.tmdb.org/t/p";
type AdType = "banner-top" | "banner-bottom" | "popunder";
type Tab = "settings" | "ads" | "embeds" | "custom";

const input = "w-full bg-gray-800 border border-gray-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-red-600 transition-colors";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-gray-400 text-xs font-medium mb-1.5 uppercase tracking-wide">{label}</label>
      {children}
    </div>
  );
}

/* ─── TMDB / IMDB Lookup Widget ─── */
interface LookupResult {
  id: number;
  title?: string;
  name?: string;
  overview?: string;
  poster_path?: string | null;
  backdrop_path?: string | null;
  release_date?: string;
  first_air_date?: string;
  media_type?: string;
  imdb_id?: string;
}

function TmdbLookup({
  onResult,
}: {
  onResult: (r: LookupResult) => void;
}) {
  const [query, setQuery] = useState("");
  const [mediaType, setMediaType] = useState<"movie" | "tv">("movie");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [found, setFound] = useState<LookupResult | null>(null);

  const fetch_ = async () => {
    if (!query.trim()) return;
    setLoading(true);
    setError("");
    setFound(null);
    try {
      const isImdb = query.trim().toLowerCase().startsWith("tt");
      const url = isImdb
        ? `/api/tmdb/find?imdb_id=${encodeURIComponent(query.trim())}`
        : `/api/tmdb/find?tmdb_id=${encodeURIComponent(query.trim())}&type=${mediaType}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Tidak ditemukan");
      const data: LookupResult = await res.json();
      setFound(data);
    } catch {
      setError("Film tidak ditemukan. Cek ID-nya lagi.");
    } finally {
      setLoading(false);
    }
  };

  const apply = () => {
    if (found) { onResult(found); setFound(null); setQuery(""); }
  };

  return (
    <div className="bg-gray-800/60 border border-white/10 rounded-xl p-4 mb-4">
      <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide mb-3 flex items-center gap-1.5">
        <Search className="w-3.5 h-3.5" /> Cari via TMDB ID / IMDB ID
      </p>
      <div className="flex gap-2">
        <input
          className={`${input} flex-1`}
          placeholder="TMDB ID (mis: 550) atau IMDB ID (mis: tt0137523)"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === "Enter" && fetch_()}
        />
        <select
          className="bg-gray-800 border border-gray-700 text-white rounded-lg px-2 py-2 text-sm focus:outline-none focus:border-red-600"
          value={mediaType}
          onChange={e => setMediaType(e.target.value as "movie" | "tv")}
        >
          <option value="movie">Movie</option>
          <option value="tv">TV</option>
        </select>
        <button
          type="button"
          onClick={fetch_}
          disabled={loading}
          className="bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-colors"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
          Fetch
        </button>
      </div>
      {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
      {found && (
        <div className="mt-3 flex items-center gap-3 bg-gray-900 rounded-lg p-3 border border-green-800/40">
          {found.poster_path && (
            <img src={`${IMG}/w92${found.poster_path}`} alt="" className="w-10 h-14 rounded object-cover flex-shrink-0" />
          )}
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-semibold truncate">{found.title ?? found.name}</p>
            <p className="text-gray-500 text-xs">
              {found.media_type?.toUpperCase()} · {(found.release_date ?? found.first_air_date ?? "").slice(0, 4)}
              {found.imdb_id && ` · ${found.imdb_id}`}
            </p>
          </div>
          <button
            type="button"
            onClick={apply}
            className="flex items-center gap-1 bg-green-700 hover:bg-green-600 text-white text-xs px-3 py-1.5 rounded-lg font-medium transition-colors flex-shrink-0"
          >
            <Check className="w-3.5 h-3.5" /> Pakai
          </button>
        </div>
      )}
    </div>
  );
}

/* ─── LOGIN PAGE ─── */
function LoginPage({ onLogin }: { onLogin: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const login = useAdminLogin();

  const handle = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      const res = await login.mutateAsync({ password });
      setToken(res.token);
      onLogin();
    } catch {
      setError("Password salah");
    }
  };

  return (
    <div className="min-h-screen bg-[#141414] flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-gray-900 rounded-xl p-8 shadow-2xl border border-white/10">
        <div className="flex items-center gap-3 mb-8">
          <Tv className="w-8 h-8 text-red-600" />
          <div>
            <h1 className="text-xl font-black text-white">XpoGo Admin</h1>
            <p className="text-xs text-gray-500">Streaming Management</p>
          </div>
        </div>
        <form onSubmit={handle} className="space-y-4">
          <div>
            <label className="block text-gray-400 text-sm mb-1.5">Admin Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="password" value={password} onChange={e => setPassword(e.target.value)}
                placeholder="Enter password" autoFocus
                className="w-full bg-gray-800 border border-gray-700 text-white rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-red-600"
              />
            </div>
            {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
          </div>
          <button type="submit" disabled={login.isPending}
            className="w-full bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white font-semibold py-2.5 rounded-lg transition-colors">
            {login.isPending ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
}

/* ─── SETTINGS TAB ─── */
function SettingsTab() {
  const { data: settings, isLoading } = useGetSettings();
  const update = useUpdateSettings();
  const [form, setForm] = useState({
    siteTitle: "XpoGo", playerColor: "E50914", playerServer: "1",
    playerDomainAd: "", posterSize: "medium", fontFamily: "Inter, sans-serif", autoplay: true,
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (settings) setForm(f => ({ ...f, ...(settings as Record<string, unknown>) }));
  }, [settings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await update.mutateAsync(form as Parameters<typeof update.mutateAsync>[0]);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  if (isLoading) return <div className="text-gray-400">Loading...</div>;

  return (
    <div className="max-w-2xl">
      <h2 className="text-white text-2xl font-bold mb-6">Site Settings</h2>
      <form onSubmit={handleSave} className="space-y-5">
        <Field label="Site Title">
          <input className={input} value={form.siteTitle} onChange={e => setForm({ ...form, siteTitle: e.target.value })} />
        </Field>
        <Field label="Player Accent Color (hex, no #)">
          <div className="flex gap-3 items-center">
            <input className={`${input} flex-1`} value={form.playerColor} onChange={e => setForm({ ...form, playerColor: e.target.value })} maxLength={6} placeholder="E50914" />
            <div className="w-10 h-10 rounded border border-white/20 flex-shrink-0" style={{ background: `#${form.playerColor}` }} />
          </div>
        </Field>
        <Field label="Player Server">
          <select className={input} value={form.playerServer} onChange={e => setForm({ ...form, playerServer: e.target.value })}>
            <option value="1">Server 1</option>
            <option value="2">Server 2</option>
            <option value="3">Server 3</option>
          </select>
        </Field>
        <Field label="Player Domain Ad (optional)">
          <input className={input} value={form.playerDomainAd} onChange={e => setForm({ ...form, playerDomainAd: e.target.value })} placeholder="yourdomain.com" />
        </Field>
        <Field label="Poster Size">
          <select className={input} value={form.posterSize} onChange={e => setForm({ ...form, posterSize: e.target.value })}>
            <option value="sm">Small</option>
            <option value="medium">Medium</option>
            <option value="lg">Large</option>
          </select>
        </Field>
        <Field label="Font Family">
          <select className={input} value={form.fontFamily} onChange={e => setForm({ ...form, fontFamily: e.target.value })}>
            <option value="Inter, sans-serif">Inter</option>
            <option value="Roboto, sans-serif">Roboto</option>
            <option value="Poppins, sans-serif">Poppins</option>
            <option value="Georgia, serif">Georgia</option>
          </select>
        </Field>
        <Field label="Autoplay">
          <label className="flex items-center gap-3 cursor-pointer">
            <div onClick={() => setForm({ ...form, autoplay: !form.autoplay })}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${form.autoplay ? "bg-red-600" : "bg-gray-700"}`}>
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${form.autoplay ? "translate-x-7" : "translate-x-1"}`} />
            </div>
            <span className="text-gray-300 text-sm">{form.autoplay ? "Enabled" : "Disabled"}</span>
          </label>
        </Field>
        <button type="submit" disabled={update.isPending}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white font-semibold px-6 py-2.5 rounded-lg transition-colors">
          <Save className="w-4 h-4" />
          {saved ? "Saved!" : update.isPending ? "Saving..." : "Save Settings"}
        </button>
      </form>
    </div>
  );
}

/* ─── ADS TAB ─── */
function AdsTab() {
  const { data: ads = [], isLoading, refetch } = useGetAds();
  const create = useCreateAd();
  const update = useUpdateAd();
  const del = useDeleteAd();
  const [form, setForm] = useState({ type: "banner-top" as AdType, label: "", code: "", active: true });
  const [adding, setAdding] = useState(false);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    await create.mutateAsync(form as Parameters<typeof create.mutateAsync>[0]);
    setForm({ type: "banner-top", label: "", code: "", active: true });
    setAdding(false); refetch();
  };

  const toggleActive = async (id: string, active: boolean) => {
    await update.mutateAsync({ id, active: !active } as Parameters<typeof update.mutateAsync>[0]);
    refetch();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Hapus iklan ini?")) return;
    await del.mutateAsync({ id } as Parameters<typeof del.mutateAsync>[0]);
    refetch();
  };

  const adTypeLabel: Record<AdType, string> = {
    "banner-top": "Banner Atas", "banner-bottom": "Banner Bawah", "popunder": "Popunder",
  };
  const adTypeBadge: Record<AdType, string> = {
    "banner-top": "bg-blue-600", "banner-bottom": "bg-purple-600", "popunder": "bg-orange-600",
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white text-2xl font-bold">Ads Manager</h2>
        <button onClick={() => setAdding(!adding)} className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
          <Plus className="w-4 h-4" /> Tambah Iklan
        </button>
      </div>
      {adding && (
        <form onSubmit={handleCreate} className="bg-gray-900 border border-white/10 rounded-xl p-6 mb-6 space-y-4">
          <h3 className="text-white font-semibold">Iklan Baru</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Label">
              <input className={input} required value={form.label} onChange={e => setForm({ ...form, label: e.target.value })} placeholder="mis: Banner Atas 728x90" />
            </Field>
            <Field label="Jenis Iklan">
              <select className={input} value={form.type} onChange={e => setForm({ ...form, type: e.target.value as AdType })}>
                <option value="banner-top">Banner Atas (sticky atas halaman)</option>
                <option value="banner-bottom">Banner Bawah (sticky bawah halaman)</option>
                <option value="popunder">Popunder (buka tab di belakang)</option>
              </select>
            </Field>
          </div>
          <Field label="Kode Iklan (HTML / Script)">
            <textarea className={`${input} h-36 resize-y font-mono text-xs`} required
              value={form.code} onChange={e => setForm({ ...form, code: e.target.value })}
              placeholder="Paste kode HTML atau script dari jaringan iklan kamu di sini..." />
          </Field>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
              <input type="checkbox" checked={form.active} onChange={e => setForm({ ...form, active: e.target.checked })} className="accent-red-600" />
              Aktif
            </label>
            <button type="submit" disabled={create.isPending} className="bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors">
              {create.isPending ? "Menyimpan..." : "Simpan Iklan"}
            </button>
            <button type="button" onClick={() => setAdding(false)} className="text-gray-400 hover:text-white text-sm transition-colors">Batal</button>
          </div>
        </form>
      )}
      {isLoading ? <div className="text-gray-400">Loading...</div>
        : (ads as { id: string; type: AdType; label: string; code: string; active: boolean }[]).length === 0 ? (
          <div className="text-center py-16 text-gray-600">
            <Megaphone className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>Belum ada iklan. Tambah iklan di atas.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {(ads as { id: string; type: AdType; label: string; code: string; active: boolean }[]).map((ad) => (
              <div key={ad.id} className={`bg-gray-900 border rounded-xl p-4 flex items-center gap-4 transition-all ${ad.active ? "border-white/10" : "border-white/5 opacity-60"}`}>
                <span className={`${adTypeBadge[ad.type]} text-white text-xs font-bold px-2 py-1 rounded flex-shrink-0`}>{adTypeLabel[ad.type]}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium">{ad.label}</p>
                  <p className="text-gray-600 text-xs font-mono truncate mt-0.5">{ad.code.slice(0, 80)}…</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button onClick={() => toggleActive(ad.id, ad.active)} title={ad.active ? "Nonaktifkan" : "Aktifkan"} className="text-gray-400 hover:text-white transition-colors p-1">
                    {ad.active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button onClick={() => handleDelete(ad.id)} className="text-red-500 hover:text-red-400 transition-colors p-1">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
    </div>
  );
}

/* ─── EMBEDS TAB ─── */
interface EmbedItem {
  id: string; type: string; title: string; url: string;
  sub?: string; active: boolean; tmdbId?: number;
}

const emptyEmbed = { type: "movie" as "movie" | "series", title: "", url: "", sub: "", tmdbId: "", active: true };

function EmbedsTab() {
  const { data: embeds = [], isLoading, refetch } = useGetEmbeds();
  const create = useCreateEmbed();
  const update = useUpdateEmbed();
  const del = useDeleteEmbed();

  const [adding, setAdding] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...emptyEmbed });

  const startEdit = (em: EmbedItem) => {
    setEditId(em.id);
    setForm({ type: em.type as "movie" | "series", title: em.title, url: em.url, sub: em.sub ?? "", tmdbId: String(em.tmdbId ?? ""), active: em.active });
    setAdding(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const cancelEdit = () => { setEditId(null); setForm({ ...emptyEmbed }); };

  const handleLookup = (r: LookupResult) => {
    setForm(f => ({
      ...f,
      title: r.title ?? r.name ?? f.title,
      type: r.media_type === "tv" ? "series" : "movie",
      tmdbId: String(r.id),
    }));
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    await create.mutateAsync({
      type: form.type, title: form.title, url: form.url,
      sub: form.sub || undefined, tmdbId: form.tmdbId ? Number(form.tmdbId) : undefined, active: form.active,
    } as Parameters<typeof create.mutateAsync>[0]);
    setForm({ ...emptyEmbed }); setAdding(false); refetch();
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editId) return;
    await update.mutateAsync({
      id: editId, type: form.type, title: form.title, url: form.url,
      sub: form.sub || undefined, tmdbId: form.tmdbId ? Number(form.tmdbId) : undefined, active: form.active,
    } as Parameters<typeof update.mutateAsync>[0]);
    cancelEdit(); refetch();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Hapus embed ini?")) return;
    await del.mutateAsync({ id } as Parameters<typeof del.mutateAsync>[0]);
    refetch();
  };

  const isEditing = !!editId;
  const showForm = adding || isEditing;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white text-2xl font-bold">Manual Embeds</h2>
        {!showForm && (
          <button onClick={() => { setAdding(true); cancelEdit(); }}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <Plus className="w-4 h-4" /> Tambah Embed
          </button>
        )}
      </div>

      {showForm && (
        <form onSubmit={isEditing ? handleUpdate : handleCreate} className="bg-gray-900 border border-white/10 rounded-xl p-6 mb-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-semibold">{isEditing ? "✏️ Edit Embed" : "Embed Baru"}</h3>
            <button type="button" onClick={() => { setAdding(false); cancelEdit(); }} className="text-gray-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          <TmdbLookup onResult={handleLookup} />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Judul Film / Series">
              <input className={input} required value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="Nama film atau series" />
            </Field>
            <Field label="Tipe">
              <select className={input} value={form.type} onChange={e => setForm({ ...form, type: e.target.value as "movie" | "series" })}>
                <option value="movie">Movie</option>
                <option value="series">Series / TV</option>
              </select>
            </Field>
            <Field label="URL Embed (link player)">
              <input className={input} required value={form.url} onChange={e => setForm({ ...form, url: e.target.value })} placeholder="https://..." type="url" />
            </Field>
            <Field label="Bahasa Subtitle (opsional)">
              <input className={input} value={form.sub} onChange={e => setForm({ ...form, sub: e.target.value })} placeholder="en, id, ar, ..." />
            </Field>
            <Field label="TMDB ID (opsional)">
              <input className={input} value={form.tmdbId} onChange={e => setForm({ ...form, tmdbId: e.target.value })} placeholder="Otomatis terisi setelah Fetch" type="number" />
            </Field>
          </div>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
              <input type="checkbox" checked={form.active} onChange={e => setForm({ ...form, active: e.target.checked })} className="accent-red-600" />
              Aktif
            </label>
            <button type="submit" disabled={create.isPending || update.isPending}
              className="bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors">
              {(create.isPending || update.isPending) ? "Menyimpan..." : isEditing ? "Update Embed" : "Simpan Embed"}
            </button>
            <button type="button" onClick={() => { setAdding(false); cancelEdit(); }} className="text-gray-400 hover:text-white text-sm transition-colors">Batal</button>
          </div>
        </form>
      )}

      {isLoading ? <div className="text-gray-400">Loading...</div>
        : (embeds as EmbedItem[]).length === 0 ? (
          <div className="text-center py-16 text-gray-600">
            <Link2 className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>Belum ada embed. Tambah di atas.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {(embeds as EmbedItem[]).map((em) => (
              <div key={em.id} className={`bg-gray-900 border rounded-xl p-4 flex items-center gap-4 ${editId === em.id ? "border-red-600/50 bg-red-950/10" : em.active ? "border-white/10" : "border-white/5 opacity-60"}`}>
                <span className={`text-xs font-bold px-2 py-1 rounded flex-shrink-0 ${em.type === "movie" ? "bg-blue-600" : "bg-green-700"} text-white`}>
                  {em.type === "movie" ? "Movie" : "Series"}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium">{em.title}</p>
                  <p className="text-gray-500 text-xs truncate">{em.url}</p>
                  <div className="flex gap-2 mt-0.5">
                    {em.tmdbId && <span className="text-xs text-blue-400">TMDB: {em.tmdbId}</span>}
                    {em.sub && <span className="text-xs text-gray-500">Sub: {em.sub}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => startEdit(em)} className="text-gray-400 hover:text-yellow-400 transition-colors p-1.5" title="Edit">
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleDelete(em.id)} className="text-red-500 hover:text-red-400 transition-colors p-1.5" title="Hapus">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
    </div>
  );
}

/* ─── CUSTOM MOVIES TAB ─── */
interface CustomMovieItem {
  id: string; title: string; type: string; year?: number;
  posterUrl?: string; backdropUrl?: string; description?: string;
  embedUrl: string; tmdbId?: number; imdbId?: string;
}

const emptyMovie = {
  title: "", description: "", posterUrl: "", backdropUrl: "",
  year: "", embedUrl: "", type: "movie" as "movie" | "series",
  tmdbId: "", imdbId: "",
};

function CustomMoviesTab() {
  const { data: movies = [], isLoading, refetch } = useGetCustomMovies();
  const create = useCreateCustomMovie();
  const del = useDeleteCustomMovie();

  const [adding, setAdding] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...emptyMovie });

  const startEdit = (m: CustomMovieItem) => {
    setEditId(m.id);
    setForm({
      title: m.title, description: m.description ?? "",
      posterUrl: m.posterUrl ?? "", backdropUrl: m.backdropUrl ?? "",
      year: String(m.year ?? ""), embedUrl: m.embedUrl,
      type: m.type as "movie" | "series",
      tmdbId: String(m.tmdbId ?? ""), imdbId: m.imdbId ?? "",
    });
    setAdding(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const cancelEdit = () => { setEditId(null); setForm({ ...emptyMovie }); };

  const handleLookup = (r: LookupResult) => {
    setForm(f => ({
      ...f,
      title: r.title ?? r.name ?? f.title,
      description: r.overview ?? f.description,
      posterUrl: r.poster_path ? `${IMG}/w500${r.poster_path}` : f.posterUrl,
      backdropUrl: r.backdrop_path ? `${IMG}/original${r.backdrop_path}` : f.backdropUrl,
      year: (r.release_date ?? r.first_air_date ?? "").slice(0, 4) || f.year,
      type: r.media_type === "tv" ? "series" : "movie",
      tmdbId: String(r.id),
      imdbId: r.imdb_id ?? f.imdbId,
    }));
  };

  const buildPayload = () => ({
    title: form.title,
    description: form.description || undefined,
    posterUrl: form.posterUrl || undefined,
    backdropUrl: form.backdropUrl || undefined,
    year: form.year ? Number(form.year) : undefined,
    embedUrl: form.embedUrl,
    type: form.type,
    tmdbId: form.tmdbId ? Number(form.tmdbId) : undefined,
    imdbId: form.imdbId || undefined,
  });

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    await create.mutateAsync(buildPayload() as Parameters<typeof create.mutateAsync>[0]);
    setForm({ ...emptyMovie }); setAdding(false); refetch();
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editId) return;
    await fetch(`/api/custom-movies/${editId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
      body: JSON.stringify(buildPayload()),
    });
    cancelEdit(); refetch();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Hapus film ini?")) return;
    await del.mutateAsync({ id } as Parameters<typeof del.mutateAsync>[0]);
    refetch();
  };

  const isEditing = !!editId;
  const showForm = adding || isEditing;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white text-2xl font-bold">Custom Movies</h2>
        {!showForm && (
          <button onClick={() => { setAdding(true); cancelEdit(); }}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <Plus className="w-4 h-4" /> Tambah Film
          </button>
        )}
      </div>

      {showForm && (
        <form onSubmit={isEditing ? handleUpdate : handleCreate} className="bg-gray-900 border border-white/10 rounded-xl p-6 mb-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-semibold">{isEditing ? `✏️ Edit: ${form.title}` : "Film Baru"}</h3>
            <button type="button" onClick={() => { setAdding(false); cancelEdit(); }} className="text-gray-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          <TmdbLookup onResult={handleLookup} />

          {(form.posterUrl || form.backdropUrl) && (
            <div className="flex gap-3">
              {form.posterUrl && (
                <div className="text-center">
                  <img src={form.posterUrl} alt="" className="h-24 rounded shadow-lg object-cover" />
                  <p className="text-gray-600 text-xs mt-1">Poster</p>
                </div>
              )}
              {form.backdropUrl && (
                <div className="text-center flex-1">
                  <img src={form.backdropUrl} alt="" className="h-24 w-full rounded shadow-lg object-cover" />
                  <p className="text-gray-600 text-xs mt-1">Backdrop</p>
                </div>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Judul">
              <input className={input} required value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="Judul film" />
            </Field>
            <Field label="Tipe">
              <select className={input} value={form.type} onChange={e => setForm({ ...form, type: e.target.value as "movie" | "series" })}>
                <option value="movie">Movie</option>
                <option value="series">Series / TV</option>
              </select>
            </Field>
            <Field label="URL Embed / Player">
              <input className={input} required value={form.embedUrl} onChange={e => setForm({ ...form, embedUrl: e.target.value })} type="url" placeholder="https://..." />
            </Field>
            <Field label="Tahun Rilis">
              <input className={input} value={form.year} onChange={e => setForm({ ...form, year: e.target.value })} type="number" placeholder="2024" />
            </Field>
            <Field label="TMDB ID">
              <input className={input} value={form.tmdbId} onChange={e => setForm({ ...form, tmdbId: e.target.value })} placeholder="Otomatis dari Fetch" type="number" />
            </Field>
            <Field label="IMDB ID">
              <input className={input} value={form.imdbId} onChange={e => setForm({ ...form, imdbId: e.target.value })} placeholder="tt1234567" />
            </Field>
            <Field label="URL Poster">
              <input className={input} value={form.posterUrl} onChange={e => setForm({ ...form, posterUrl: e.target.value })} type="url" placeholder="Otomatis dari Fetch" />
            </Field>
            <Field label="URL Backdrop">
              <input className={input} value={form.backdropUrl} onChange={e => setForm({ ...form, backdropUrl: e.target.value })} type="url" placeholder="Otomatis dari Fetch" />
            </Field>
          </div>
          <Field label="Deskripsi">
            <textarea className={`${input} h-20 resize-none`} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Otomatis dari Fetch" />
          </Field>
          <div className="flex items-center gap-4">
            <button type="submit" disabled={create.isPending}
              className="bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors">
              {create.isPending ? "Menyimpan..." : isEditing ? "Update Film" : "Simpan Film"}
            </button>
            <button type="button" onClick={() => { setAdding(false); cancelEdit(); }} className="text-gray-400 hover:text-white text-sm transition-colors">Batal</button>
          </div>
        </form>
      )}

      {isLoading ? <div className="text-gray-400">Loading...</div>
        : (movies as CustomMovieItem[]).length === 0 ? (
          <div className="text-center py-16 text-gray-600">
            <Film className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>Belum ada film. Tambah di atas.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {(movies as CustomMovieItem[]).map((m) => (
              <div key={m.id} className={`bg-gray-900 rounded-lg overflow-hidden border group transition-all ${editId === m.id ? "border-red-600/60" : "border-white/10"}`}>
                <div className="aspect-[2/3] bg-gray-800 relative">
                  {m.posterUrl ? (
                    <img src={m.posterUrl} alt={m.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-700 p-2 text-center">
                      <Film className="w-8 h-8" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                    <button onClick={() => startEdit(m)} className="bg-yellow-500 hover:bg-yellow-400 text-black rounded-full w-8 h-8 flex items-center justify-center" title="Edit">
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => handleDelete(m.id)} className="bg-red-600 hover:bg-red-500 text-white rounded-full w-8 h-8 flex items-center justify-center" title="Hapus">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <div className="p-2">
                  <p className="text-white text-xs font-medium truncate">{m.title}</p>
                  <p className="text-gray-500 text-xs">{m.year} · {m.type}</p>
                  {m.tmdbId && <p className="text-blue-500 text-xs">TMDB: {m.tmdbId}</p>}
                </div>
              </div>
            ))}
          </div>
        )}
    </div>
  );
}

/* ─── MAIN ADMIN ─── */
export default function AdminPage() {
  const [loggedIn, setLoggedIn] = useState(!!getToken());
  const [activeTab, setActiveTab] = useState<Tab>("settings");
  const qc = useQueryClient();
  const verify = useAdminVerify({ enabled: loggedIn, retry: false });

  useEffect(() => {
    if (verify.isError) { clearToken(); setLoggedIn(false); }
  }, [verify.isError]);

  if (!loggedIn) return <LoginPage onLogin={() => setLoggedIn(true)} />;

  return (
    <div className="min-h-screen bg-[#141414] pt-16">
      <div className="bg-gray-900 border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between h-14">
          <div className="flex items-center gap-4">
            <span className="text-white font-bold hidden sm:flex items-center gap-2">
              <Tv className="w-5 h-5 text-red-600" /> Admin
            </span>
            <div className="flex gap-1">
              {([
                { id: "settings", label: "Settings", icon: Settings },
                { id: "ads", label: "Iklan", icon: Megaphone },
                { id: "embeds", label: "Embeds", icon: Link2 },
                { id: "custom", label: "Custom Films", icon: Film },
              ] as { id: Tab; label: string; icon: React.ElementType }[]).map(({ id, label, icon: Icon }) => (
                <button key={id} onClick={() => setActiveTab(id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-sm font-medium transition-colors ${activeTab === id ? "bg-red-600 text-white" : "text-gray-400 hover:text-white hover:bg-white/10"}`}>
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{label}</span>
                </button>
              ))}
            </div>
          </div>
          <button onClick={() => { clearToken(); setLoggedIn(false); qc.clear(); }}
            className="flex items-center gap-1.5 text-gray-400 hover:text-white text-sm transition-colors">
            <LogOut className="w-4 h-4" /> <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-4 py-8">
        {activeTab === "settings" && <SettingsTab />}
        {activeTab === "ads" && <AdsTab />}
        {activeTab === "embeds" && <EmbedsTab />}
        {activeTab === "custom" && <CustomMoviesTab />}
      </div>
    </div>
  );
}
