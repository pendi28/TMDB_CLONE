import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useGetAds, setAuthTokenGetter, setBaseUrl } from "@workspace/api-client-react";
import { getToken } from "@/lib/auth";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home";
import MoviePage from "@/pages/movie";
import TvPage from "@/pages/tv";
import SearchPage from "@/pages/search";
import AdminPage from "@/pages/admin";
import Navbar from "@/components/Navbar";
import AdBanner from "@/components/AdBanner";
import ContentRow from "@/components/ContentRow";
import { useGetPopularMovies, useGetPopularTv } from "@workspace/api-client-react";

setAuthTokenGetter(() => getToken());
if (import.meta.env.VITE_API_URL) setBaseUrl(import.meta.env.VITE_API_URL);

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 1000 * 60 * 5, retry: 1 } },
});

interface AdItem {
  id: string;
  type: "banner-top" | "banner-bottom" | "popunder";
  label: string;
  code: string;
  active: boolean;
}

function AppContent() {
  const { data: ads = [] } = useGetAds();
  const activeAds = (ads as AdItem[]).filter((a) => a.active);
  const hasTop = activeAds.some((a) => a.type === "banner-top");
  const hasBottom = activeAds.some((a) => a.type === "banner-bottom");

  return (
    <div className="dark">
      <AdBanner ads={activeAds} />
      <div
        style={{
          paddingTop: hasTop ? 60 : 0,
          paddingBottom: hasBottom ? 60 : 0,
        }}
      >
        <Navbar />
        <main>
          <Switch>
            <Route path="/" component={HomePage} />
            <Route path="/movie/:id" component={MoviePage} />
            <Route path="/tv/:id" component={TvPage} />
            <Route path="/movies" component={MoviesPage} />
            <Route path="/tv" component={TvListPage} />
            <Route path="/search" component={SearchPage} />
            <Route path="/admin" component={AdminPage} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
      <Toaster />
    </div>
  );
}

function MoviesPage() {
  const { data } = useGetPopularMovies({ page: 1 });
  return (
    <div className="min-h-screen bg-[#141414] pt-24 pb-20 px-4 sm:px-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-white text-3xl font-black mb-8">Movies</h1>
        {data?.results && <ContentRow title="Popular Movies" items={data.results} mediaType="movie" />}
      </div>
    </div>
  );
}

function TvListPage() {
  const { data } = useGetPopularTv({ page: 1 });
  return (
    <div className="min-h-screen bg-[#141414] pt-24 pb-20 px-4 sm:px-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-white text-3xl font-black mb-8">TV Shows</h1>
        {data?.results && <ContentRow title="Popular TV Shows" items={data.results} mediaType="tv" />}
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <AppContent />
      </WouterRouter>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
