import { useState, useEffect, useRef } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, Image,
  StyleSheet, ActivityIndicator, Dimensions, StatusBar,
  SafeAreaView, Animated, BackHandler, Modal, TextInput,
  TouchableWithoutFeedback, Alert, Platform,
} from "react-native";
import { useRouter } from "expo-router";
import {
  useGetTrending, useGetPopularMovies, useGetPopularTv,
  useGetTopRatedMovies, useGetTopRatedTv, setBaseUrl,
} from "@workspace/api-client-react";
import { setAdminToken, isAdminLoggedIn, getAdminToken } from "@/lib/adminStore";

const FALLBACK = "b30fc0f2-ea8a-424a-88ee-fa02e53bd00a-00-1n14z61p3qun8.pike.replit.dev";
const API_URL = `https://${process.env.EXPO_PUBLIC_DOMAIN || FALLBACK}`;
setBaseUrl(API_URL);

const IMG_W = "https://image.tmdb.org/t/p/w342";
const IMG_B = "https://image.tmdb.org/t/p/w780";
const { width, height } = Dimensions.get("window");
const DRAWER_W = Math.min(width * 0.82, 320);
const CARD_W = (width - 56) / 3.2;
const BG = "#0d1117";
const CARD_BG = "#1a2332";
const GREEN = "#00c853";
const GRAY = "#8a9bb0";
const GENRES = ["Aksi", "Komedi", "Drama", "Horor", "Fiksi Ilmiah", "Animasi", "Thriller"];

interface MediaItem {
  id: number; title?: string; name?: string;
  poster_path?: string | null; backdrop_path?: string | null;
  vote_average?: number; media_type?: string; overview?: string;
}
interface CustomMovie {
  id: string; title: string; posterUrl?: string; backdropUrl?: string;
  type: "movie" | "series"; tmdbId?: number; description?: string;
}

function RatingBadge({ score }: { score?: number }) {
  if (!score) return null;
  const pct = Math.round(score * 10);
  const color = pct >= 70 ? GREEN : pct >= 50 ? "#f5c518" : "#e74c3c";
  return (
    <View style={[S.ratingBadge, { borderColor: color }]}>
      <Text style={[S.ratingText, { color }]}>{pct}%</Text>
    </View>
  );
}

function MediaCard({ item, type }: { item: MediaItem; type: "movie" | "tv" }) {
  const router = useRouter();
  const mt = (item.media_type as "movie" | "tv") ?? type;
  return (
    <TouchableOpacity
      style={S.card}
      onPress={() => router.push((mt === "tv" ? `/tv/${item.id}` : `/movie/${item.id}`) as never)}
      activeOpacity={0.85}
    >
      <View style={S.posterWrap}>
        {item.poster_path
          ? <Image source={{ uri: `${IMG_W}${item.poster_path}` }} style={S.poster} />
          : <View style={[S.poster, S.noImg]}><Text style={{ color: "#444", fontSize: 9, textAlign: "center", padding: 4 }}>{item.title ?? item.name}</Text></View>
        }
        <RatingBadge score={item.vote_average} />
      </View>
      <Text style={S.cardTitle} numberOfLines={2}>{item.title ?? item.name}</Text>
    </TouchableOpacity>
  );
}

function CustomCard({ m }: { m: CustomMovie }) {
  const router = useRouter();
  return (
    <TouchableOpacity
      style={S.card}
      onPress={() => router.push((m.tmdbId ? `/movie/${m.tmdbId}` : `/movie/${m.id}`) as never)}
      activeOpacity={0.85}
    >
      <View style={S.posterWrap}>
        {m.posterUrl
          ? <Image source={{ uri: m.posterUrl }} style={S.poster} />
          : <View style={[S.poster, { backgroundColor: CARD_BG, alignItems: "center", justifyContent: "center" }]}><Text style={{ fontSize: 28 }}>🎬</Text></View>
        }
        <View style={[S.ratingBadge, { backgroundColor: "rgba(229,9,20,0.9)", borderColor: "#E50914" }]}>
          <Text style={[S.ratingText, { color: "#fff" }]}>{m.type === "series" ? "S" : "M"}</Text>
        </View>
      </View>
      <Text style={S.cardTitle} numberOfLines={2}>{m.title}</Text>
    </TouchableOpacity>
  );
}

function SectionRow({ title, items, type, seeAll }: {
  title: string; items: MediaItem[]; type: "movie" | "tv"; seeAll?: () => void;
}) {
  if (!items.length) return null;
  return (
    <View style={S.section}>
      <View style={S.sectionHeader}>
        <Text style={S.sectionTitle}>{title}</Text>
        {seeAll && (
          <TouchableOpacity onPress={seeAll} style={S.seeAllBtn} activeOpacity={0.7}>
            <Text style={S.seeAllText}>Semua</Text>
          </TouchableOpacity>
        )}
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, gap: 12 }}>
        {items.map(item => <MediaCard key={item.id} item={item} type={type} />)}
      </ScrollView>
    </View>
  );
}

// ─── HERO BANNER ─────────────────────────────────────────────────
function HeroBanner({ item, onWatch, onInfo }: {
  item: MediaItem; onWatch: () => void; onInfo: () => void;
}) {
  const pct = item.vote_average ? Math.round(item.vote_average * 10) : 0;
  const rColor = pct >= 70 ? GREEN : pct >= 50 ? "#f5c518" : "#e74c3c";
  return (
    <View style={S.hero}>
      {item.backdrop_path
        ? <Image source={{ uri: `${IMG_B}${item.backdrop_path}` }} style={S.heroImg} resizeMode="cover" />
        : <View style={S.heroImgPlaceholder} />
      }
      <View style={S.heroGrad} />
      <View style={S.heroContent}>
        <View style={S.heroBadge}>
          <Text style={S.heroBadgeText}>
            {pct > 0 ? `⭐ ${pct}% · ` : ""}{item.media_type === "tv" ? "Serial TV" : "Film"}
          </Text>
        </View>
        <Text style={S.heroTitle} numberOfLines={2}>{item.title ?? item.name}</Text>
        {item.overview ? <Text style={S.heroOverview} numberOfLines={2}>{item.overview}</Text> : null}
        <View style={S.heroBtns}>
          <TouchableOpacity style={S.btnWatch} onPress={onWatch} activeOpacity={0.85}>
            <Text style={S.btnWatchText}>▶  Tonton</Text>
          </TouchableOpacity>
          <TouchableOpacity style={S.btnInfo} onPress={onInfo} activeOpacity={0.85}>
            <Text style={S.btnInfoText}>ℹ  Info</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

// ─── DRAWER ──────────────────────────────────────────────────────
function DrawerMenu({
  visible, onClose, isAdmin, onOpenLogin, onGoAdmin, onLogout,
}: {
  visible: boolean; onClose: () => void; isAdmin: boolean;
  onOpenLogin: () => void; onGoAdmin: () => void; onLogout: () => void;
}) {
  const slideX = useRef(new Animated.Value(-DRAWER_W)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(slideX, { toValue: visible ? 0 : -DRAWER_W, duration: 240, useNativeDriver: true }),
      Animated.timing(opacity, { toValue: visible ? 1 : 0, duration: 240, useNativeDriver: true }),
    ]).start();
  }, [visible]);

  const LIBRARY = [
    { icon: "❤️", label: "Favorit" },
    { icon: "🔖", label: "Daftar Tonton" },
    { icon: "⭐", label: "Dinilai" },
    { icon: "📋", label: "Daftar Saya" },
  ];

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents={visible ? "auto" : "none"}>
      <TouchableWithoutFeedback onPress={onClose}>
        <Animated.View style={[S.drawerOverlay, { opacity }]} />
      </TouchableWithoutFeedback>

      <Animated.View style={[S.drawerPanel, { transform: [{ translateX: slideX }] }]}>
        <SafeAreaView style={{ flex: 1 }}>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
            <View style={S.drawerHeader}>
              <View style={S.drawerAvatar}>
                <Text style={{ fontSize: 28 }}>{isAdmin ? "🛡️" : "👤"}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={S.drawerName}>{isAdmin ? "Admin" : "Tamu"}</Text>
                <Text style={S.drawerSub}>{isAdmin ? "Mode Admin Aktif" : "Masuk untuk semua fitur"}</Text>
              </View>
              {!isAdmin && (
                <TouchableOpacity style={S.drawerMasukBtn} onPress={onOpenLogin} activeOpacity={0.8}>
                  <Text style={S.drawerMasukText}>Masuk</Text>
                </TouchableOpacity>
              )}
            </View>

            <Text style={S.drawerLabel}>PERPUSTAKAAN SAYA</Text>
            <View style={S.drawerCard}>
              {LIBRARY.map((item, i) => (
                <View key={item.label}>
                  <TouchableOpacity style={S.drawerRow} activeOpacity={0.7}>
                    <View style={S.drawerIcon}><Text style={{ fontSize: 15 }}>{item.icon}</Text></View>
                    <Text style={S.drawerRowLabel}>{item.label}</Text>
                    <Text style={{ color: GRAY, fontSize: 15 }}>🔒</Text>
                  </TouchableOpacity>
                  {i < LIBRARY.length - 1 && <View style={S.divider} />}
                </View>
              ))}
            </View>

            <Text style={S.drawerLabel}>JELAJAHI</Text>
            <View style={S.drawerCard}>
              <TouchableOpacity style={S.drawerRow} activeOpacity={0.7}>
                <View style={[S.drawerIcon, { backgroundColor: "#0a3d1f" }]}><Text style={{ fontSize: 15 }}>🧭</Text></View>
                <Text style={S.drawerRowLabel}>Jelajahi</Text>
                <Text style={{ color: GRAY, fontSize: 18 }}>›</Text>
              </TouchableOpacity>
            </View>

            <View style={S.drawerAdminCard}>
              {isAdmin ? (
                <>
                  <TouchableOpacity style={S.drawerRow} activeOpacity={0.85}
                    onPress={() => { onClose(); setTimeout(onGoAdmin, 280); }}>
                    <View style={[S.drawerIcon, { backgroundColor: "#0a3d1f" }]}><Text style={{ fontSize: 15 }}>🛡️</Text></View>
                    <View style={{ flex: 1 }}>
                      <Text style={[S.drawerRowLabel, { color: GREEN }]}>Buka Admin Panel</Text>
                      <Text style={{ color: GRAY, fontSize: 11, marginTop: 1 }}>Kelola film, iklan & settings</Text>
                    </View>
                    <Text style={{ color: GREEN, fontSize: 18 }}>›</Text>
                  </TouchableOpacity>
                  <View style={S.divider} />
                  <TouchableOpacity style={S.drawerRow} activeOpacity={0.85} onPress={onLogout}>
                    <View style={[S.drawerIcon, { backgroundColor: "#3a0a0a" }]}><Text style={{ fontSize: 15 }}>🚪</Text></View>
                    <Text style={[S.drawerRowLabel, { color: "#ff4d4d" }]}>Logout Admin</Text>
                  </TouchableOpacity>
                </>
              ) : (
                <TouchableOpacity style={S.drawerRow} activeOpacity={0.85} onPress={onOpenLogin}>
                  <View style={[S.drawerIcon, { backgroundColor: "#0a3d1f" }]}><Text style={{ fontSize: 15 }}>🛡️</Text></View>
                  <View style={{ flex: 1 }}>
                    <Text style={[S.drawerRowLabel, { color: GREEN }]}>Login Admin</Text>
                    <Text style={{ color: GRAY, fontSize: 11, marginTop: 1 }}>Akses khusus pengelola konten</Text>
                  </View>
                  <Text style={{ color: GREEN, fontSize: 18 }}>›</Text>
                </TouchableOpacity>
              )}
            </View>
          </ScrollView>
        </SafeAreaView>
      </Animated.View>
    </View>
  );
}

// ─── HOME SCREEN ─────────────────────────────────────────────────
export default function HomeScreen() {
  const router = useRouter();
  const [trendingTab, setTrendingTab] = useState<"day" | "week">("week");
  const [activeGenre, setActiveGenre] = useState<string | null>(null);
  const [customMovies, setCustomMovies] = useState<CustomMovie[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [loginModal, setLoginModal] = useState(false);
  const [password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [adminActive, setAdminActive] = useState(false);
  const [loginMode, setLoginMode] = useState<"login" | "setup" | "change">("login");
  const [passwordSet, setPasswordSet] = useState<boolean | null>(null);

  const { data: trending, isLoading } = useGetTrending({ media_type: "all", time_window: trendingTab, page: 1 });
  const { data: trendingDay } = useGetTrending({ media_type: "all", time_window: "day", page: 1 });
  const { data: movies } = useGetPopularMovies({ page: 1 });
  const { data: tv } = useGetPopularTv({ page: 1 });
  const { data: topMovies } = useGetTopRatedMovies({ page: 1 });
  const { data: topTv } = useGetTopRatedTv({ page: 1 });

  const loadCustom = () => {
    fetch(`${API_URL}/api/custom-movies`)
      .then(r => r.json())
      .then((d: CustomMovie[]) => { if (Array.isArray(d)) setCustomMovies(d); })
      .catch(() => {});
  };

  useEffect(() => { loadCustom(); }, []);

  useEffect(() => { setAdminActive(isAdminLoggedIn()); }, [loginModal, drawerOpen]);

  useEffect(() => {
    const h = BackHandler.addEventListener("hardwareBackPress", () => {
      if (drawerOpen) { setDrawerOpen(false); return true; }
      if (loginModal) { setLoginModal(false); return true; }
      return false;
    });
    return () => h.remove();
  }, [drawerOpen, loginModal]);

  const closeLogin = () => {
    setLoginModal(false); setPassword(""); setNewPassword("");
    setLoginError(""); setLoginMode("login");
  };

  const checkPasswordStatus = async () => {
    try {
      const r = await fetch(`${API_URL}/api/admin/status`);
      const d = await r.json();
      const isSet = d.passwordSet ?? false;
      setPasswordSet(isSet);
      // Auto-setup HANYA jika password belum pernah dibuat
      // Setelah dibuat, opsi setup tidak pernah muncul lagi
      if (!isSet) setLoginMode("setup");
      else setLoginMode("login");
    } catch {
      setPasswordSet(true); // aman: anggap sudah di-set jika tidak bisa cek
      setLoginMode("login");
    }
  };

  const doLogin = async () => {
    if (!password.trim()) return;
    setLoginLoading(true); setLoginError("");
    try {
      const res = await fetch(`${API_URL}/api/admin/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (data.token) {
        setAdminToken(data.token);
        setAdminActive(true);
        closeLogin();
        setDrawerOpen(false);
        Alert.alert("✅ Berhasil", "Login admin berhasil!");
      } else {
        if (data.passwordSet === false) {
          setLoginMode("setup");
          setLoginError("⚠️ Password belum di-set. Buat password baru di bawah.");
        } else {
          setLoginError("❌ Password salah!");
        }
      }
    } catch {
      setLoginError("❌ Tidak bisa terhubung ke server.");
    } finally { setLoginLoading(false); }
  };

  const doSetup = async () => {
    if (!password.trim() || password.trim().length < 4) {
      setLoginError("❌ Password minimal 4 karakter.");
      return;
    }
    setLoginLoading(true); setLoginError("");
    try {
      const res = await fetch(`${API_URL}/api/admin/setup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (data.token) {
        setAdminToken(data.token);
        setAdminActive(true);
        closeLogin();
        setDrawerOpen(false);
        Alert.alert("✅ Password Disimpan!", "Password berhasil dibuat dan kamu sudah login sebagai admin!");
      } else {
        setLoginError("❌ " + (data.error ?? "Gagal setup password."));
        if (data.error?.includes("sudah di-set")) setLoginMode("login");
      }
    } catch {
      setLoginError("❌ Tidak bisa terhubung ke server.");
    } finally { setLoginLoading(false); }
  };

  const doChangePassword = async () => {
    if (!password.trim() || !newPassword.trim() || newPassword.trim().length < 4) {
      setLoginError("❌ Password baru minimal 4 karakter.");
      return;
    }
    setLoginLoading(true); setLoginError("");
    try {
      const res = await fetch(`${API_URL}/api/admin/change-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: password, newPassword }),
      });
      const data = await res.json();
      if (data.token) {
        setAdminToken(data.token);
        setAdminActive(true);
        closeLogin();
        setDrawerOpen(false);
        Alert.alert("✅ Password Diganti!", "Password berhasil diganti dan kamu sudah login!");
      } else {
        setLoginError("❌ " + (data.error ?? "Gagal ganti password."));
      }
    } catch {
      setLoginError("❌ Tidak bisa terhubung ke server.");
    } finally { setLoginLoading(false); }
  };

  const doLogout = () => {
    setAdminToken(null);
    setAdminActive(false);
    setDrawerOpen(false);
    Alert.alert("Logout", "Berhasil logout admin.");
  };

  const trendResults = (trendingTab === "day" ? trendingDay : trending)?.results as MediaItem[] ?? [];
  const popularMovies = movies?.results as MediaItem[] ?? [];
  const popularTv = tv?.results as MediaItem[] ?? [];
  const topRatedMovies = topMovies?.results as MediaItem[] ?? [];
  const onAir = topTv?.results as MediaItem[] ?? [];
  const heroItem = trendResults[0] ?? popularMovies[0];

  return (
    <View style={S.container}>
      <StatusBar barStyle="light-content" backgroundColor={BG} translucent />

      {/* HEADER */}
      <SafeAreaView style={S.headerSafe}>
        <View style={S.header}>
          <TouchableOpacity style={S.headerIcon} activeOpacity={0.7} onPress={() => setDrawerOpen(true)}>
            <Text style={{ color: "#fff", fontSize: 20 }}>☰</Text>
          </TouchableOpacity>
          <Text style={S.logoText}>Xpo<Text style={{ color: GREEN }}>Go</Text></Text>
          <TouchableOpacity style={S.headerIcon} activeOpacity={0.7}>
            <Text style={{ color: "#fff", fontSize: 18 }}>🔍</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>

        {/* HERO */}
        {heroItem && !isLoading && (
          <HeroBanner
            item={heroItem}
            onWatch={() => router.push((heroItem.media_type === "tv" ? `/tv/${heroItem.id}` : `/movie/${heroItem.id}`) as never)}
            onInfo={() => router.push((heroItem.media_type === "tv" ? `/tv/${heroItem.id}` : `/movie/${heroItem.id}`) as never)}
          />
        )}

        {isLoading
          ? <ActivityIndicator color={GREEN} size="large" style={{ marginTop: 60 }} />
          : <>
              {/* GENRE CHIPS */}
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={S.genres}>
                {GENRES.map(g => (
                  <TouchableOpacity
                    key={g}
                    style={[S.genreChip, activeGenre === g && S.genreChipActive]}
                    onPress={() => setActiveGenre(activeGenre === g ? null : g)}
                    activeOpacity={0.8}
                  >
                    <Text style={[S.genreText, activeGenre === g && S.genreTextActive]}>{g}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              {customMovies.length > 0 && (
                <View style={S.section}>
                  <View style={S.sectionHeader}>
                    <Text style={S.sectionTitle}>🎬 Film Khusus</Text>
                  </View>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, gap: 12 }}>
                    {customMovies.map(m => <CustomCard key={m.id} m={m} />)}
                  </ScrollView>
                </View>
              )}

              <SectionRow title="🔥 Populer" items={popularMovies} type="movie" seeAll={() => {}} />

              <View style={S.section}>
                <View style={S.sectionHeader}>
                  <Text style={S.sectionTitle}>📈 Trending</Text>
                  <View style={S.toggleRow}>
                    {(["day", "week"] as const).map(tab => (
                      <TouchableOpacity
                        key={tab}
                        style={[S.toggleBtn, trendingTab === tab && S.toggleBtnActive]}
                        onPress={() => setTrendingTab(tab)}
                        activeOpacity={0.8}
                      >
                        <Text style={[S.toggleText, trendingTab === tab && S.toggleTextActive]}>
                          {tab === "day" ? "Hari ini" : "Minggu ini"}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, gap: 12 }}>
                  {trendResults.map(item => <MediaCard key={item.id} item={item} type="movie" />)}
                </ScrollView>
              </View>

              <SectionRow title="⭐ Penilaian Teratas" items={topRatedMovies} type="movie" />
              <SectionRow title="📺 Serial Populer" items={popularTv} type="tv" />
              <SectionRow title="🏆 Serial Terbaik" items={onAir} type="tv" />
            </>
        }
      </ScrollView>

      {/* DRAWER */}
      <DrawerMenu
        visible={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        isAdmin={adminActive}
        onOpenLogin={() => { setDrawerOpen(false); setTimeout(() => { setLoginModal(true); checkPasswordStatus(); }, 280); }}
        onGoAdmin={() => router.push("/admin" as never)}
        onLogout={doLogout}
      />

      {/* LOGIN MODAL */}
      <Modal visible={loginModal} transparent animationType="fade" onRequestClose={closeLogin}>
        <TouchableWithoutFeedback onPress={closeLogin}>
          <View style={S.modalOverlay}>
            <TouchableWithoutFeedback>
              <View style={S.modalBox}>
                {/* ICON + JUDUL */}
                <View style={{ alignItems: "center", marginBottom: 14 }}>
                  <View style={{ width: 54, height: 54, borderRadius: 27, backgroundColor: loginMode === "setup" ? "#1a2d0a" : "#0a3d1f", alignItems: "center", justifyContent: "center", marginBottom: 10, borderWidth: 2, borderColor: loginMode === "setup" ? "#f59e0b" : GREEN }}>
                    <Text style={{ fontSize: 24 }}>{loginMode === "setup" ? "🔑" : loginMode === "change" ? "🔄" : "🛡️"}</Text>
                  </View>
                  <Text style={S.modalTitle}>
                    {loginMode === "setup" ? "Buat Password Admin" : loginMode === "change" ? "Ganti Password" : "Login Admin"}
                  </Text>
                  <Text style={S.modalSub}>
                    {loginMode === "setup"
                      ? "Password belum ada. Buat password baru untuk Firebase kamu."
                      : loginMode === "change"
                      ? "Masukkan password lama lalu buat password baru."
                      : "Masukkan password admin yang tersimpan di Firebase."}
                  </Text>
                </View>

                {/* INPUT PASSWORD LAMA / UTAMA */}
                <TextInput
                  style={S.modalInput}
                  placeholder={loginMode === "change" ? "Password lama..." : "Password admin..."}
                  placeholderTextColor={GRAY}
                  secureTextEntry
                  value={password}
                  onChangeText={setPassword}
                  onSubmitEditing={loginMode === "setup" ? doSetup : loginMode === "change" ? undefined : doLogin}
                  autoFocus
                />

                {/* INPUT PASSWORD BARU (hanya mode change) */}
                {loginMode === "change" && (
                  <TextInput
                    style={[S.modalInput, { marginTop: 8 }]}
                    placeholder="Password baru (min 4 karakter)..."
                    placeholderTextColor={GRAY}
                    secureTextEntry
                    value={newPassword}
                    onChangeText={setNewPassword}
                    onSubmitEditing={doChangePassword}
                  />
                )}

                {/* ERROR / INFO */}
                {loginError ? (
                  <Text style={[S.errorText, loginError.startsWith("⚠️") && { color: "#f59e0b" }]}>
                    {loginError}
                  </Text>
                ) : null}

                {/* TOMBOL AKSI */}
                <View style={{ flexDirection: "row", gap: 8, marginTop: 10 }}>
                  <TouchableOpacity
                    style={[S.modalBtn, { backgroundColor: loginMode === "setup" ? "#f59e0b" : GREEN }]}
                    onPress={loginMode === "setup" ? doSetup : loginMode === "change" ? doChangePassword : doLogin}
                    activeOpacity={0.8}
                    disabled={loginLoading}
                  >
                    {loginLoading
                      ? <ActivityIndicator color="#fff" size="small" />
                      : <Text style={S.modalBtnText}>
                          {loginMode === "setup" ? "Simpan Password" : loginMode === "change" ? "Ganti" : "Login"}
                        </Text>
                    }
                  </TouchableOpacity>
                  <TouchableOpacity style={[S.modalBtn, { backgroundColor: "#2a3a4a" }]} onPress={closeLogin} activeOpacity={0.8}>
                    <Text style={S.modalBtnText}>Batal</Text>
                  </TouchableOpacity>
                </View>

                {/* LINK MODE LAIN — setup tidak ada manual link, hanya auto */}
                <View style={{ marginTop: 14, flexDirection: "row", justifyContent: "center", gap: 16 }}>
                  {loginMode === "change" && (
                    <TouchableOpacity onPress={() => { setLoginMode("login"); setLoginError(""); setPassword(""); setNewPassword(""); }} activeOpacity={0.7}>
                      <Text style={S.linkText}>← Kembali Login</Text>
                    </TouchableOpacity>
                  )}
                  {loginMode === "login" && passwordSet !== false && (
                    <TouchableOpacity onPress={() => { setLoginMode("change"); setLoginError(""); setPassword(""); }} activeOpacity={0.7}>
                      <Text style={S.linkText}>Ganti Password</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
}

const S = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  headerSafe: { backgroundColor: "transparent", zIndex: 10 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 10 },
  headerIcon: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(26,35,50,0.9)", alignItems: "center", justifyContent: "center" },
  logoText: { color: "#fff", fontSize: 22, fontWeight: "900", letterSpacing: -1 },

  // HERO
  hero: { marginHorizontal: 14, height: height * 0.28, borderRadius: 16, overflow: "hidden", position: "relative", marginBottom: 12, marginTop: 6 },
  heroImg: { position: "absolute", width: "100%", height: "100%" },
  heroImgPlaceholder: { position: "absolute", width: "100%", height: "100%", backgroundColor: CARD_BG },
  heroGrad: { position: "absolute", inset: 0, backgroundColor: "transparent" },
  heroContent: { position: "absolute", bottom: 0, left: 0, right: 0, padding: 14, paddingBottom: 14 },
  heroBadge: { alignSelf: "flex-start", backgroundColor: "rgba(0,200,83,.2)", borderWidth: 1, borderColor: GREEN, borderRadius: 16, paddingHorizontal: 8, paddingVertical: 2, marginBottom: 6 },
  heroBadgeText: { color: GREEN, fontSize: 10, fontWeight: "700" },
  heroTitle: { color: "#fff", fontSize: 17, fontWeight: "900", lineHeight: 22, marginBottom: 8, textShadowColor: "rgba(0,0,0,.9)", textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 4 },
  heroOverview: { color: "rgba(255,255,255,.7)", fontSize: 11, lineHeight: 15, marginBottom: 10 },
  heroBtns: { flexDirection: "row", gap: 8 },
  btnWatch: { backgroundColor: GREEN, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 8 },
  btnWatchText: { color: "#fff", fontWeight: "800", fontSize: 12 },
  btnInfo: { backgroundColor: "rgba(255,255,255,.14)", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1, borderColor: "rgba(255,255,255,.2)" },
  btnInfoText: { color: "#fff", fontWeight: "700", fontSize: 12 },

  genres: { paddingHorizontal: 16, gap: 8, paddingVertical: 14 },
  genreChip: { borderRadius: 20, borderWidth: 1.5, borderColor: "#2a3a4a", paddingHorizontal: 16, paddingVertical: 8 },
  genreChipActive: { backgroundColor: GREEN, borderColor: GREEN },
  genreText: { color: GRAY, fontSize: 13, fontWeight: "600" },
  genreTextActive: { color: "#fff" },

  section: { marginBottom: 26 },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, marginBottom: 12 },
  sectionTitle: { color: "#fff", fontSize: 17, fontWeight: "800" },
  seeAllBtn: { backgroundColor: GREEN, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 5 },
  seeAllText: { color: "#fff", fontSize: 12, fontWeight: "700" },

  toggleRow: { flexDirection: "row", backgroundColor: CARD_BG, borderRadius: 20, padding: 3 },
  toggleBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 18 },
  toggleBtnActive: { backgroundColor: GREEN },
  toggleText: { color: GRAY, fontSize: 12, fontWeight: "600" },
  toggleTextActive: { color: "#fff" },

  card: { width: CARD_W },
  posterWrap: { position: "relative", borderRadius: 10, overflow: "hidden" },
  poster: { width: CARD_W, aspectRatio: 2 / 3, borderRadius: 10, backgroundColor: CARD_BG },
  noImg: { alignItems: "center", justifyContent: "center" },
  ratingBadge: { position: "absolute", top: 6, left: 6, backgroundColor: "rgba(13,17,23,0.88)", borderRadius: 12, paddingHorizontal: 6, paddingVertical: 3, borderWidth: 1.5, borderColor: GREEN },
  ratingText: { color: "#fff", fontSize: 10, fontWeight: "800" },
  cardTitle: { color: "#c8d6e5", fontSize: 12, marginTop: 7, lineHeight: 16, fontWeight: "500" },

  drawerOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(0,0,0,0.72)" },
  drawerPanel: { position: "absolute", left: 0, top: 0, bottom: 0, width: DRAWER_W, backgroundColor: "#0d1420", borderRightWidth: 1, borderRightColor: "#1a2332", shadowColor: "#000", shadowOpacity: 0.6, shadowRadius: 24, elevation: 24 },
  drawerHeader: { flexDirection: "row", alignItems: "center", gap: 12, padding: 20, paddingTop: Platform.OS === "android" ? 40 : 24, backgroundColor: "#111d2e", marginBottom: 6 },
  drawerAvatar: { width: 52, height: 52, borderRadius: 26, backgroundColor: CARD_BG, alignItems: "center", justifyContent: "center" },
  drawerName: { color: "#fff", fontSize: 17, fontWeight: "800" },
  drawerSub: { color: GRAY, fontSize: 11, marginTop: 2 },
  drawerMasukBtn: { backgroundColor: GREEN, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 8 },
  drawerMasukText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  drawerLabel: { color: GRAY, fontSize: 10, fontWeight: "700", letterSpacing: 1.2, paddingHorizontal: 16, marginBottom: 6, marginTop: 12 },
  drawerCard: { backgroundColor: CARD_BG, borderRadius: 14, marginHorizontal: 12, marginBottom: 4, overflow: "hidden" },
  drawerAdminCard: { backgroundColor: "#091a10", borderRadius: 14, marginHorizontal: 12, marginTop: 14, borderWidth: 1.5, borderColor: GREEN, overflow: "hidden" },
  drawerRow: { flexDirection: "row", alignItems: "center", padding: 14, gap: 12 },
  drawerIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: "#2a3a4a", alignItems: "center", justifyContent: "center" },
  drawerRowLabel: { flex: 1, color: "#fff", fontSize: 14, fontWeight: "600" },
  divider: { height: 1, backgroundColor: "rgba(255,255,255,.04)", marginLeft: 62 },

  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.82)", alignItems: "center", justifyContent: "center", padding: 24 },
  modalBox: { backgroundColor: "#111d2e", borderRadius: 18, padding: 24, width: "100%", borderWidth: 1, borderColor: "#2a3a4a" },
  modalTitle: { color: "#fff", fontSize: 20, fontWeight: "900", marginBottom: 6, textAlign: "center" },
  modalSub: { color: GRAY, fontSize: 12, textAlign: "center", lineHeight: 17 },
  modalInput: { backgroundColor: BG, color: "#fff", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14, fontSize: 15, marginBottom: 8, borderWidth: 1.5, borderColor: "#2a3a4a", marginTop: 16 },
  errorText: { color: "#ff4d4d", fontSize: 12, marginBottom: 6, textAlign: "center" },
  modalBtn: { flex: 1, borderRadius: 10, paddingVertical: 13, alignItems: "center" },
  modalBtnText: { color: "#fff", fontWeight: "700", fontSize: 15 },
  linkText: { color: GREEN, fontSize: 13, fontWeight: "600", textDecorationLine: "underline" },
});
