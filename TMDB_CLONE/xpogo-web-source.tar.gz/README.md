# XpoGo Streaming Web

Web streaming platform berbasis TMDB + Firebase.

## Tech Stack
- React + Vite + TypeScript
- TailwindCSS + shadcn/ui
- Firebase Realtime Database
- TMDB API

## Setup Lokal

```bash
# Clone repo
git clone https://github.com/pendi28/TMDB_CLONE.git
cd TMDB_CLONE

# Install dependencies
npm install

# Buat file .env
echo "VITE_TMDB_KEY=your_tmdb_api_key_here" > .env

# Jalankan dev server
npm run dev
```

## Build & Deploy ke Firebase

```bash
# Build
VITE_TMDB_KEY=your_key npm run build

# Deploy
FIREBASE_TOKEN=your_token npx firebase deploy --only hosting
```

## Struktur Folder

```
src/
├── pages/
│   ├── home.tsx       # Halaman utama
│   ├── movie.tsx      # Detail film
│   ├── tv.tsx         # Detail series
│   ├── search.tsx     # Pencarian
│   └── admin.tsx      # Admin panel (/admin)
├── components/
│   ├── Navbar.tsx
│   ├── ContentRow.tsx
│   └── MovieCard.tsx
└── lib/
    ├── firebase.ts    # Firebase helper
    ├── tmdb.ts        # TMDB API helper
    └── types.ts       # TypeScript types
```

## Environment Variables

| Variable | Keterangan |
|---|---|
| `VITE_TMDB_KEY` | API key dari themoviedb.org |

## Firebase Config
Edit `src/lib/firebase.ts` → ganti URL database dengan milikmu.

## Admin Panel
Akses di `/admin` → login dengan password yang sudah di-set di Firebase.
