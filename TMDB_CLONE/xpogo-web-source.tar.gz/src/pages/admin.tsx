import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fb, hashPassword } from "@/lib/firebase";
import { tmdb } from "@/lib/tmdb";
import { getToken, setToken, clearToken, setWriteToken, clearWriteToken } from "@/lib/auth";
import type { Settings, Ad, Embed, CustomMovie, TmdbListItem, TmdbFindResult } from "@/lib/types";
import {
  Settings as SettingsIcon, Megaphone, Film, Link2, LogOut, Plus, Trash2,
  Eye, EyeOff, Save, Lock, Tv, Pencil, Search, Check, X, Loader2,
} from "lucide-react";

const IMG = "https://image.tmdb.org/t/p";
type Tab = "settings" | "ads" | "embeds" | "custom";

const inputCls = "w-full bg-gray-800 border border-gray-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-red-600 transition-colors";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-gray-400 text-xs font-medium mb-1.5 uppercase tracking-wide">{label}</label>
      {children}
    </div>
  );
}

/* ─── TMDB Lookup Widget ─── */
function TmdbLookup({ onResult }: { onResult: (r: TmdbListItem & { imdb_id?: string }) => void }) {
  const [query,     setQuery]     = useState("");
  const [mediaType, setMediaType] = useState<"movie" | "tv">("movie");
  const [loading,   setLoading]   = useState(false);
  const [error,     setError]     = useState("");
  const [found,     setFound]     = useState<(TmdbListItem & { imdb_id?: string }) | null>(null);

  const fetchItem = async () => {
    if (!query.trim()) return;
    setLoading(true); setError(""); setFound(null);
    try {
      const isImdb = query.trim().toLowerCase().startsWith("tt");
      if (isImdb) {
        const res: TmdbFindResult = await tmdb.findByImdb(query.trim());
        const item = res.movie_results[0] ?? res.tv_results[0] ?? null;
        if (!item) throw new Error("not found");
        setFound({ ...item, media_type: res.movie_results[0] ? "movie" : "tv" });
      } else {
        const numId = Number(query.trim());
        if (!numId) throw new Error("invalid id");
        const res = mediaType === "tv"
          ? await tmdb.tvDetail(numId)
          : await tmdb.movieDetail(numId);
        const item: TmdbListItem & { imdb_id?: string } = {
          id:             res.id,
          title:          "title" in res ? res.title : undefined,
          name:           "name"  in res ? res.name  : undefined,
          overview:       res.overview,
          poster_path:    res.poster_path,
          backdrop_path:  res.backdrop_path,
          release_date:   "release_date"    in res ? res.release_date    : undefined,
          first_air_date: "first_air_date"  in res ? res.first_air_date  : undefined,
          media_type:     mediaType,
          imdb_id:        "imdb_id" in res ? (res as { imdb_id?: string }).imdb_id : undefined,
        };
        setFound(item);
      }
    } catch {
      setError("Film tidak ditemukan. Cek ID-nya lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-800/60 border border-white/10 rounded-xl p-4 mb-4">
      <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide mb-3 flex items-center gap-1.5">
        <Search className="w-3.5 h-3.5" /> Cari via TMDB ID / IMDB ID
      </p>
      <div className="flex gap-2">
        <input
          className={`${inputCls} flex-1`}
          placeholder="TMDB ID (mis: 550) atau IMDB ID (mis: tt0137523)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && fetchItem()}
        />
        <select
          className="bg-gray-800 border border-gray-700 text-white rounded-lg px-2 py-2 text-sm focus:outline-none focus:border-red-600"
          value={mediaType}
          onChange={(e) => setMediaType(e.target.value as "movie" | "tv")}
        >
          <option value="movie">Movie</option>
          <option value="tv">TV</option>
        </select>
        <button type="button" onClick={fetchItem} disabled={loading}
          className="bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-colors">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />} Fetch
        </button>
      </div>
      {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
      {found && (
        <div className="mt-3 flex items-center gap-3 bg-gray-900 rounded-lg p-3 border border-green-800/40">
          {found.poster_path && (
            <img src={`${IMG}/w92${found.poster_path}`} alt="" className="w-10 h-14 rounded object-cover flex-shrink-0" />
          )}
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-semibold truncate">{found.title ?? found.name}</p>
            <p className="text-gray-500 text-xs">
              {found.media_type?.toUpperCase()} · {(found.release_date ?? found.first_air_date ?? "").slice(0, 4)}
              {found.imdb_id && ` · ${found.imdb_id}`}
            </p>
          </div>
          <button type="button" onClick={() => { onResult(found); setFound(null); setQuery(""); }}
            className="flex items-center gap-1 bg-green-700 hover:bg-green-600 text-white text-xs px-3 py-1.5 rounded-lg font-medium transition-colors flex-shrink-0">
            <Check className="w-3.5 h-3.5" /> Pakai
          </button>
        </div>
      )}
    </div>
  );
}

/* ─── LOGIN PAGE ─── */
function LoginPage({ onLogin }: { onLogin: () => void }) {
  const [password, setPassword] = useState("");
  const [error,    setError]    = useState("");
  const [loading,  setLoading]  = useState(false);

  const handle = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const hash   = await hashPassword(password);
      const stored = await fb.getPasswordHash();
      if (!stored || hash !== stored) throw new Error("wrong password");
      setToken(hash);        // persist login state (hash, not raw password)
      setWriteToken(password); // write token = raw password → stored in sessionStorage only
      onLogin();
    } catch {
      setError("Password salah");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#141414] flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-gray-900 rounded-xl p-8 shadow-2xl border border-white/10">
        <div className="flex items-center gap-3 mb-8">
          <Tv className="w-8 h-8 text-red-600" />
          <div>
            <h1 className="text-xl font-black text-white">XpoGo Admin</h1>
            <p className="text-xs text-gray-500">Streaming Management</p>
          </div>
        </div>
        <form onSubmit={handle} className="space-y-4">
          <div>
            <label className="block text-gray-400 text-sm mb-1.5">Admin Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password" autoFocus
                className="w-full bg-gray-800 border border-gray-700 text-white rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-red-600"
              />
            </div>
            {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
          </div>
          <button type="submit" disabled={loading}
            className="w-full bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white font-semibold py-2.5 rounded-lg transition-colors">
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
}

/* ─── SETTINGS TAB ─── */
type SettingsForm = {
  siteTitle: string; playerColor: string; playerServer: string;
  playerDomainAd: string; posterSize: string; fontFamily: string; autoplay: boolean;
};

function SettingsTab() {
  const qc = useQueryClient();
  const { data: settings, isLoading } = useQuery<Settings | null>({ queryKey: ["settings"], queryFn: fb.getSettings });
  const [form, setForm] = useState<SettingsForm>({
    siteTitle: "XpoGo", playerColor: "E50914", playerServer: "1",
    playerDomainAd: "", posterSize: "medium", fontFamily: "Inter, sans-serif", autoplay: true,
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (settings) {
      setForm((f) => ({
        ...f,
        siteTitle:      settings.siteTitle      ?? f.siteTitle,
        playerColor:    settings.playerColor     ?? f.playerColor,
        playerServer:   settings.playerServer    ?? f.playerServer,
        playerDomainAd: settings.playerDomainAd  ?? f.playerDomainAd,
        posterSize:     settings.posterSize      ?? f.posterSize,
        fontFamily:     settings.fontFamily      ?? f.fontFamily,
        autoplay:       settings.autoplay !== "false",
      }));
    }
  }, [settings]);

  const save = useMutation({
    mutationFn: (data: Settings) => fb.setSettings(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["settings"] });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    save.mutate({ ...form, autoplay: form.autoplay ? "true" : "false" });
  };

  if (isLoading) return <div className="text-gray-400">Loading...</div>;

  return (
    <div className="max-w-2xl">
      <h2 className="text-white text-2xl font-bold mb-6">Site Settings</h2>
      <form onSubmit={handleSubmit} className="space-y-5">
        <Field label="Site Title">
          <input className={inputCls} value={form.siteTitle} onChange={(e) => setForm({ ...form, siteTitle: e.target.value })} />
        </Field>
        <Field label="Player Accent Color (hex, no #)">
          <div className="flex gap-3 items-center">
            <input className={`${inputCls} flex-1`} value={form.playerColor} onChange={(e) => setForm({ ...form, playerColor: e.target.value })} maxLength={6} placeholder="E50914" />
            <div className="w-10 h-10 rounded border border-white/20 flex-shrink-0" style={{ background: `#${form.playerColor}` }} />
          </div>
        </Field>
        <Field label="Player Server">
          <select className={inputCls} value={form.playerServer} onChange={(e) => setForm({ ...form, playerServer: e.target.value })}>
            <option value="1">Server 1</option>
            <option value="2">Server 2</option>
            <option value="3">Server 3</option>
          </select>
        </Field>
        <Field label="Player Domain Ad (optional)">
          <input className={inputCls} value={form.playerDomainAd} onChange={(e) => setForm({ ...form, playerDomainAd: e.target.value })} placeholder="yourdomain.com" />
        </Field>
        <Field label="Poster Size">
          <select className={inputCls} value={form.posterSize} onChange={(e) => setForm({ ...form, posterSize: e.target.value })}>
            <option value="sm">Small</option>
            <option value="medium">Medium</option>
            <option value="lg">Large</option>
          </select>
        </Field>
        <Field label="Font Family">
          <select className={inputCls} value={form.fontFamily} onChange={(e) => setForm({ ...form, fontFamily: e.target.value })}>
            <option value="Inter, sans-serif">Inter</option>
            <option value="Roboto, sans-serif">Roboto</option>
            <option value="Poppins, sans-serif">Poppins</option>
            <option value="Georgia, serif">Georgia</option>
          </select>
        </Field>
        <Field label="Autoplay">
          <label className="flex items-center gap-3 cursor-pointer">
            <div onClick={() => setForm({ ...form, autoplay: !form.autoplay })}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${form.autoplay ? "bg-red-600" : "bg-gray-700"}`}>
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${form.autoplay ? "translate-x-7" : "translate-x-1"}`} />
            </div>
            <span className="text-gray-300 text-sm">{form.autoplay ? "Enabled" : "Disabled"}</span>
          </label>
        </Field>
        <button type="submit" disabled={save.isPending}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white font-semibold px-6 py-2.5 rounded-lg transition-colors">
          <Save className="w-4 h-4" />
          {saved ? "Saved!" : save.isPending ? "Saving..." : "Save Settings"}
        </button>
      </form>
    </div>
  );
}

/* ─── ADS TAB ─── */
type AdForm = { type: Ad["type"]; label: string; code: string; active: boolean };
const emptyAd: AdForm = { type: "banner-top", label: "", code: "", active: true };
const adTypeLabel: Record<Ad["type"], string> = { "banner-top": "Banner Atas", "banner-bottom": "Banner Bawah", "popunder": "Popunder" };
const adTypeBadge: Record<Ad["type"], string> = { "banner-top": "bg-blue-600", "banner-bottom": "bg-purple-600", "popunder": "bg-orange-600" };

function AdsTab() {
  const qc = useQueryClient();
  const { data: ads = [], isLoading } = useQuery<Ad[]>({ queryKey: ["ads"], queryFn: fb.getAds });
  const [form,   setForm]   = useState<AdForm>({ ...emptyAd });
  const [adding, setAdding] = useState(false);

  const create = useMutation({
    mutationFn: (d: Omit<Ad, "id">) => fb.addAd(d),
    onSuccess:  () => { qc.invalidateQueries({ queryKey: ["ads"] }); setForm({ ...emptyAd }); setAdding(false); },
  });
  const toggleActive = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) => fb.updateAd(id, { active }),
    onSuccess:  () => qc.invalidateQueries({ queryKey: ["ads"] }),
  });
  const del = useMutation({
    mutationFn: (id: string) => fb.deleteAd(id),
    onSuccess:  () => qc.invalidateQueries({ queryKey: ["ads"] }),
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white text-2xl font-bold">Ads Manager</h2>
        <button onClick={() => setAdding(!adding)}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
          <Plus className="w-4 h-4" /> Tambah Iklan
        </button>
      </div>
      {adding && (
        <form onSubmit={(e) => { e.preventDefault(); create.mutate(form); }}
          className="bg-gray-900 border border-white/10 rounded-xl p-6 mb-6 space-y-4">
          <h3 className="text-white font-semibold">Iklan Baru</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Label">
              <input className={inputCls} required value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="mis: Banner Atas 728x90" />
            </Field>
            <Field label="Jenis Iklan">
              <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as Ad["type"] })}>
                <option value="banner-top">Banner Atas (sticky atas)</option>
                <option value="banner-bottom">Banner Bawah (sticky bawah)</option>
                <option value="popunder">Popunder (tab di belakang)</option>
              </select>
            </Field>
          </div>
          <Field label="Kode Iklan (HTML / Script)">
            <textarea className={`${inputCls} h-36 resize-y font-mono text-xs`} required
              value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })}
              placeholder="Paste kode HTML atau script dari jaringan iklan kamu di sini..." />
          </Field>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
              <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} className="accent-red-600" />
              Aktif
            </label>
            <button type="submit" disabled={create.isPending}
              className="bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors">
              {create.isPending ? "Menyimpan..." : "Simpan Iklan"}
            </button>
            <button type="button" onClick={() => setAdding(false)} className="text-gray-400 hover:text-white text-sm transition-colors">Batal</button>
          </div>
        </form>
      )}
      {isLoading ? <div className="text-gray-400">Loading...</div>
        : ads.length === 0 ? (
          <div className="text-center py-16 text-gray-600">
            <Megaphone className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>Belum ada iklan. Tambah iklan di atas.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {ads.map((ad) => (
              <div key={ad.id} className={`bg-gray-900 border rounded-xl p-4 flex items-center gap-4 transition-all ${ad.active ? "border-white/10" : "border-white/5 opacity-60"}`}>
                <span className={`${adTypeBadge[ad.type]} text-white text-xs font-bold px-2 py-1 rounded flex-shrink-0`}>{adTypeLabel[ad.type]}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium">{ad.label}</p>
                  <p className="text-gray-600 text-xs font-mono truncate mt-0.5">{ad.code?.slice(0, 80)}…</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button onClick={() => toggleActive.mutate({ id: ad.id, active: !ad.active })} title={ad.active ? "Nonaktifkan" : "Aktifkan"} className="text-gray-400 hover:text-white transition-colors p-1">
                    {ad.active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button onClick={() => { if (confirm("Hapus iklan ini?")) del.mutate(ad.id); }} className="text-red-500 hover:text-red-400 transition-colors p-1">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
    </div>
  );
}

/* ─── EMBEDS TAB ─── */
type EmbedForm = { type: "movie" | "series"; title: string; url: string; sub: string; tmdbId: string; active: boolean };
const emptyEmbed: EmbedForm = { type: "movie", title: "", url: "", sub: "", tmdbId: "", active: true };

function EmbedsTab() {
  const qc = useQueryClient();
  const { data: embeds = [], isLoading } = useQuery<Embed[]>({ queryKey: ["embeds"], queryFn: fb.getEmbeds });
  const [adding, setAdding] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form,   setForm]   = useState<EmbedForm>({ ...emptyEmbed });

  const startEdit = (em: Embed) => {
    setEditId(em.id);
    setForm({ type: em.type, title: em.title, url: em.url, sub: em.sub ?? "", tmdbId: String(em.tmdbId ?? ""), active: em.active });
    setAdding(false);
  };
  const cancelEdit = () => { setEditId(null); setForm({ ...emptyEmbed }); };

  const handleLookup = (r: TmdbListItem) => {
    setForm((f) => ({ ...f, title: r.title ?? r.name ?? f.title, type: r.media_type === "tv" ? "series" : "movie", tmdbId: String(r.id) }));
  };

  const payload = (): Omit<Embed, "id"> => ({
    type: form.type, title: form.title, url: form.url,
    sub: form.sub || undefined, tmdbId: form.tmdbId ? Number(form.tmdbId) : undefined, active: form.active,
  });

  const create = useMutation({
    mutationFn: () => fb.addEmbed(payload()),
    onSuccess:  () => { qc.invalidateQueries({ queryKey: ["embeds"] }); setForm({ ...emptyEmbed }); setAdding(false); },
  });
  const update = useMutation({
    mutationFn: () => fb.updateEmbed(editId!, payload()),
    onSuccess:  () => { qc.invalidateQueries({ queryKey: ["embeds"] }); cancelEdit(); },
  });
  const del = useMutation({
    mutationFn: (id: string) => fb.deleteEmbed(id),
    onSuccess:  () => qc.invalidateQueries({ queryKey: ["embeds"] }),
  });

  const isEditing = !!editId;
  const showForm  = adding || isEditing;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white text-2xl font-bold">Manual Embeds</h2>
        {!showForm && (
          <button onClick={() => { setAdding(true); cancelEdit(); }}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <Plus className="w-4 h-4" /> Tambah Embed
          </button>
        )}
      </div>
      {showForm && (
        <form onSubmit={(e) => { e.preventDefault(); isEditing ? update.mutate() : create.mutate(); }}
          className="bg-gray-900 border border-white/10 rounded-xl p-6 mb-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-semibold">{isEditing ? "✏️ Edit Embed" : "Embed Baru"}</h3>
            <button type="button" onClick={() => { setAdding(false); cancelEdit(); }} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
          </div>
          <TmdbLookup onResult={handleLookup} />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Judul Film / Series">
              <input className={inputCls} required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Nama film atau series" />
            </Field>
            <Field label="Tipe">
              <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as "movie" | "series" })}>
                <option value="movie">Movie</option>
                <option value="series">Series / TV</option>
              </select>
            </Field>
            <Field label="URL Embed (link player)">
              <input className={inputCls} required value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} type="url" placeholder="https://..." />
            </Field>
            <Field label="Bahasa Subtitle (opsional)">
              <input className={inputCls} value={form.sub} onChange={(e) => setForm({ ...form, sub: e.target.value })} placeholder="en, id, ar, ..." />
            </Field>
            <Field label="TMDB ID (opsional)">
              <input className={inputCls} value={form.tmdbId} onChange={(e) => setForm({ ...form, tmdbId: e.target.value })} placeholder="Otomatis terisi setelah Fetch" type="number" />
            </Field>
          </div>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
              <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} className="accent-red-600" />
              Aktif
            </label>
            <button type="submit" disabled={create.isPending || update.isPending}
              className="bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors">
              {(create.isPending || update.isPending) ? "Menyimpan..." : isEditing ? "Update Embed" : "Simpan Embed"}
            </button>
            <button type="button" onClick={() => { setAdding(false); cancelEdit(); }} className="text-gray-400 hover:text-white text-sm transition-colors">Batal</button>
          </div>
        </form>
      )}
      {isLoading ? <div className="text-gray-400">Loading...</div>
        : embeds.length === 0 ? (
          <div className="text-center py-16 text-gray-600">
            <Link2 className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>Belum ada embed. Tambah di atas.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {embeds.map((em) => (
              <div key={em.id} className={`bg-gray-900 border rounded-xl p-4 flex items-center gap-4 ${editId === em.id ? "border-red-600/50 bg-red-950/10" : em.active ? "border-white/10" : "border-white/5 opacity-60"}`}>
                <span className={`text-xs font-bold px-2 py-1 rounded flex-shrink-0 ${em.type === "movie" ? "bg-blue-600" : "bg-green-700"} text-white`}>
                  {em.type === "movie" ? "Movie" : "Series"}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium">{em.title}</p>
                  <p className="text-gray-500 text-xs truncate">{em.url}</p>
                  <div className="flex gap-2 mt-0.5">
                    {em.tmdbId && <span className="text-xs text-blue-400">TMDB: {em.tmdbId}</span>}
                    {em.sub    && <span className="text-xs text-gray-500">Sub: {em.sub}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => startEdit(em)} className="text-gray-400 hover:text-yellow-400 transition-colors p-1.5" title="Edit"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => { if (confirm("Hapus embed ini?")) del.mutate(em.id); }} className="text-red-500 hover:text-red-400 transition-colors p-1.5" title="Hapus"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            ))}
          </div>
        )}
    </div>
  );
}

/* ─── CUSTOM MOVIES TAB ─── */
type CustomMovieForm = {
  title: string; description: string; posterUrl: string; backdropUrl: string;
  year: string; embedUrl: string; type: "movie" | "series"; tmdbId: string; imdbId: string;
};
const emptyMovie: CustomMovieForm = {
  title: "", description: "", posterUrl: "", backdropUrl: "",
  year: "", embedUrl: "", type: "movie", tmdbId: "", imdbId: "",
};

function CustomMoviesTab() {
  const qc = useQueryClient();
  const { data: movies = [], isLoading } = useQuery<CustomMovie[]>({ queryKey: ["custom_movies"], queryFn: fb.getCustomMovies });
  const [adding, setAdding] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form,   setForm]   = useState<CustomMovieForm>({ ...emptyMovie });

  const startEdit = (m: CustomMovie) => {
    setEditId(m.id);
    setForm({ title: m.title, description: m.description ?? "", posterUrl: m.posterUrl ?? "", backdropUrl: m.backdropUrl ?? "", year: String(m.year ?? ""), embedUrl: m.embedUrl, type: m.type, tmdbId: String(m.tmdbId ?? ""), imdbId: m.imdbId ?? "" });
    setAdding(false);
  };
  const cancelEdit = () => { setEditId(null); setForm({ ...emptyMovie }); };

  const handleLookup = (r: TmdbListItem & { imdb_id?: string }) => {
    setForm((f) => ({
      ...f,
      title:       r.title ?? r.name ?? f.title,
      description: r.overview ?? f.description,
      posterUrl:   r.poster_path    ? `${IMG}/w500${r.poster_path}`       : f.posterUrl,
      backdropUrl: r.backdrop_path  ? `${IMG}/original${r.backdrop_path}` : f.backdropUrl,
      year:        (r.release_date ?? r.first_air_date ?? "").slice(0, 4) || f.year,
      type:        r.media_type === "tv" ? "series" : "movie",
      tmdbId:      String(r.id),
      imdbId:      r.imdb_id ?? f.imdbId,
    }));
  };

  const payload = (): Omit<CustomMovie, "id"> => ({
    title:       form.title,
    description: form.description  || undefined,
    posterUrl:   form.posterUrl    || undefined,
    backdropUrl: form.backdropUrl  || undefined,
    year:        form.year ? Number(form.year) : undefined,
    embedUrl:    form.embedUrl,
    type:        form.type,
    tmdbId:      form.tmdbId  ? Number(form.tmdbId) : undefined,
    imdbId:      form.imdbId  || undefined,
  });

  const create = useMutation({
    mutationFn: () => fb.addCustomMovie(payload()),
    onSuccess:  () => { qc.invalidateQueries({ queryKey: ["custom_movies"] }); setForm({ ...emptyMovie }); setAdding(false); },
  });
  const update = useMutation({
    mutationFn: () => fb.updateCustomMovie(editId!, payload()),
    onSuccess:  () => { qc.invalidateQueries({ queryKey: ["custom_movies"] }); cancelEdit(); },
  });
  const del = useMutation({
    mutationFn: (id: string) => fb.deleteCustomMovie(id),
    onSuccess:  () => qc.invalidateQueries({ queryKey: ["custom_movies"] }),
  });

  const isEditing = !!editId;
  const showForm  = adding || isEditing;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white text-2xl font-bold">Custom Movies</h2>
        {!showForm && (
          <button onClick={() => { setAdding(true); cancelEdit(); }}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <Plus className="w-4 h-4" /> Tambah Film
          </button>
        )}
      </div>
      {showForm && (
        <form onSubmit={(e) => { e.preventDefault(); isEditing ? update.mutate() : create.mutate(); }}
          className="bg-gray-900 border border-white/10 rounded-xl p-6 mb-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-semibold">{isEditing ? `✏️ Edit: ${form.title}` : "Film Baru"}</h3>
            <button type="button" onClick={() => { setAdding(false); cancelEdit(); }} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
          </div>
          <TmdbLookup onResult={handleLookup} />
          {(form.posterUrl || form.backdropUrl) && (
            <div className="flex gap-3">
              {form.posterUrl    && <div className="text-center"><img src={form.posterUrl}    alt="" className="h-24 rounded shadow-lg object-cover" /><p className="text-gray-600 text-xs mt-1">Poster</p></div>}
              {form.backdropUrl  && <div className="text-center flex-1"><img src={form.backdropUrl} alt="" className="h-24 w-full rounded shadow-lg object-cover" /><p className="text-gray-600 text-xs mt-1">Backdrop</p></div>}
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Judul">
              <input className={inputCls} required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Judul film" />
            </Field>
            <Field label="Tipe">
              <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as "movie" | "series" })}>
                <option value="movie">Movie</option>
                <option value="series">Series / TV</option>
              </select>
            </Field>
            <Field label="URL Embed / Player">
              <input className={inputCls} required value={form.embedUrl} onChange={(e) => setForm({ ...form, embedUrl: e.target.value })} type="url" placeholder="https://..." />
            </Field>
            <Field label="Tahun Rilis">
              <input className={inputCls} value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} type="number" placeholder="2024" />
            </Field>
            <Field label="TMDB ID">
              <input className={inputCls} value={form.tmdbId} onChange={(e) => setForm({ ...form, tmdbId: e.target.value })} placeholder="Otomatis dari Fetch" type="number" />
            </Field>
            <Field label="IMDB ID">
              <input className={inputCls} value={form.imdbId} onChange={(e) => setForm({ ...form, imdbId: e.target.value })} placeholder="tt1234567" />
            </Field>
            <Field label="URL Poster">
              <input className={inputCls} value={form.posterUrl} onChange={(e) => setForm({ ...form, posterUrl: e.target.value })} type="url" placeholder="Otomatis dari Fetch" />
            </Field>
            <Field label="URL Backdrop">
              <input className={inputCls} value={form.backdropUrl} onChange={(e) => setForm({ ...form, backdropUrl: e.target.value })} type="url" placeholder="Otomatis dari Fetch" />
            </Field>
          </div>
          <Field label="Deskripsi">
            <textarea className={`${inputCls} h-20 resize-none`} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Otomatis dari Fetch" />
          </Field>
          <div className="flex items-center gap-4">
            <button type="submit" disabled={create.isPending || update.isPending}
              className="bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors">
              {(create.isPending || update.isPending) ? "Menyimpan..." : isEditing ? "Update Film" : "Simpan Film"}
            </button>
            <button type="button" onClick={() => { setAdding(false); cancelEdit(); }} className="text-gray-400 hover:text-white text-sm transition-colors">Batal</button>
          </div>
        </form>
      )}
      {isLoading ? <div className="text-gray-400">Loading...</div>
        : movies.length === 0 ? (
          <div className="text-center py-16 text-gray-600">
            <Film className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>Belum ada film. Tambah di atas.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {movies.map((m) => (
              <div key={m.id} className={`bg-gray-900 rounded-lg overflow-hidden border group transition-all ${editId === m.id ? "border-red-600/60" : "border-white/10"}`}>
                <div className="aspect-[2/3] bg-gray-800 relative">
                  {m.posterUrl ? (
                    <img src={m.posterUrl} alt={m.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-700"><Film className="w-8 h-8" /></div>
                  )}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                    <button onClick={() => startEdit(m)} className="bg-yellow-500 hover:bg-yellow-400 text-black rounded-full w-8 h-8 flex items-center justify-center"><Pencil className="w-3.5 h-3.5" /></button>
                    <button onClick={() => { if (confirm("Hapus film ini?")) del.mutate(m.id); }} className="bg-red-600 hover:bg-red-500 text-white rounded-full w-8 h-8 flex items-center justify-center"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                </div>
                <div className="p-2">
                  <p className="text-white text-xs font-medium truncate">{m.title}</p>
                  <p className="text-gray-500 text-xs">{m.year} · {m.type}</p>
                  {m.tmdbId && <p className="text-blue-500 text-xs">TMDB: {m.tmdbId}</p>}
                </div>
              </div>
            ))}
          </div>
        )}
    </div>
  );
}

/* ─── MAIN ADMIN ─── */
const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "settings", label: "Settings",      icon: SettingsIcon },
  { id: "ads",      label: "Iklan",         icon: Megaphone    },
  { id: "embeds",   label: "Embeds",        icon: Link2        },
  { id: "custom",   label: "Custom Films",  icon: Film         },
];

export default function AdminPage() {
  const [loggedIn,  setLoggedIn]  = useState(false);
  const [verifying, setVerifying] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>("settings");
  const qc = useQueryClient();

  useEffect(() => {
    const token = getToken();
    if (!token) { setVerifying(false); return; }
    fb.getPasswordHash()
      .then((hash) => { if (hash && token === hash) setLoggedIn(true); else clearToken(); })
      .finally(() => setVerifying(false));
  }, []);

  if (verifying) {
    return (
      <div className="min-h-screen bg-[#141414] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (!loggedIn) return <LoginPage onLogin={() => setLoggedIn(true)} />;

  return (
    <div className="min-h-screen bg-[#141414] pt-16">
      <div className="bg-gray-900 border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between h-14">
          <div className="flex items-center gap-4">
            <span className="text-white font-bold hidden sm:flex items-center gap-2">
              <Tv className="w-5 h-5 text-red-600" /> Admin
            </span>
            <div className="flex gap-1">
              {tabs.map(({ id, label, icon: Icon }) => (
                <button key={id} onClick={() => setActiveTab(id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-sm font-medium transition-colors ${activeTab === id ? "bg-red-600 text-white" : "text-gray-400 hover:text-white hover:bg-white/10"}`}>
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{label}</span>
                </button>
              ))}
            </div>
          </div>
          <button onClick={() => { clearToken(); clearWriteToken(); setLoggedIn(false); qc.clear(); }}
            className="flex items-center gap-1.5 text-gray-400 hover:text-white text-sm transition-colors">
            <LogOut className="w-4 h-4" /> <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-4 py-8">
        {activeTab === "settings" && <SettingsTab />}
        {activeTab === "ads"      && <AdsTab />}
        {activeTab === "embeds"   && <EmbedsTab />}
        {activeTab === "custom"   && <CustomMoviesTab />}
      </div>
    </div>
  );
}
