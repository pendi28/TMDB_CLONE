import { Link } from "wouter";
import { Play, Info, Star, Film } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { tmdb } from "@/lib/tmdb";
import { fb } from "@/lib/firebase";
import type { TmdbListResult, TmdbListItem, CustomMovie } from "@/lib/types";
import ContentRow from "@/components/ContentRow";

const BACKDROP_BASE = "https://image.tmdb.org/t/p/original";

function CustomMovieCard({ m }: { m: CustomMovie }) {
  return (
    <Link href={m.tmdbId ? `/movie/${m.tmdbId}` : `/movie/${m.id}`}>
      <div className="flex-shrink-0 w-32 cursor-pointer group">
        <div className="relative rounded-md overflow-hidden aspect-[2/3] bg-gray-800 mb-1.5 transition-transform group-hover:scale-105">
          {m.posterUrl ? (
            <img src={m.posterUrl} alt={m.title} className="w-full h-full object-cover" loading="lazy" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Film className="w-8 h-8 text-gray-600" />
            </div>
          )}
          <div className="absolute top-1.5 left-1.5 bg-black/70 text-yellow-400 text-[10px] font-bold px-1.5 py-0.5 rounded">
            {m.type === "series" ? "Series" : "Film"}
          </div>
        </div>
        <p className="text-gray-300 text-[11px] leading-tight line-clamp-2">{m.title}</p>
      </div>
    </Link>
  );
}

export default function HomePage() {
  const { data: trending }      = useQuery<TmdbListResult>({ queryKey: ["trending"],       queryFn: () => tmdb.trending() });
  const { data: popularMovies } = useQuery<TmdbListResult>({ queryKey: ["popular-movies"], queryFn: () => tmdb.popularMovies() });
  const { data: popularTv }     = useQuery<TmdbListResult>({ queryKey: ["popular-tv"],     queryFn: () => tmdb.popularTv() });
  const { data: topMovies }     = useQuery<TmdbListResult>({ queryKey: ["top-movies"],     queryFn: () => tmdb.topMovies() });
  const { data: topTv }         = useQuery<TmdbListResult>({ queryKey: ["top-tv"],         queryFn: () => tmdb.topTv() });
  const { data: customMovies = [] } = useQuery<CustomMovie[]>({ queryKey: ["custom_movies"], queryFn: fb.getCustomMovies });

  const hero = trending?.results?.[0] as TmdbListItem | undefined;

  return (
    <div className="min-h-screen bg-[#141414]">
      {hero && (
        <div className="relative h-[75vh] min-h-[500px]">
          {hero.backdrop_path && (
            <img
              src={`${BACKDROP_BASE}${hero.backdrop_path}`}
              alt={hero.title ?? hero.name}
              className="absolute inset-0 w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-transparent to-transparent" />
          <div className="relative h-full flex flex-col justify-end pb-16 px-8 max-w-2xl">
            <div className="flex items-center gap-2 mb-3">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-yellow-400 text-sm font-medium">{hero.vote_average?.toFixed(1)}</span>
              <span className="text-gray-400 text-sm">·</span>
              <span className="text-gray-400 text-sm capitalize">{hero.media_type ?? "movie"}</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-black text-white mb-3 leading-tight">
              {hero.title ?? hero.name}
            </h1>
            <p className="text-gray-300 text-sm sm:text-base line-clamp-3 mb-6">{hero.overview}</p>
            <div className="flex gap-3">
              <Link
                href={hero.media_type === "tv" ? `/tv/${hero.id}` : `/movie/${hero.id}`}
                className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-2.5 rounded-md transition-colors"
              >
                <Play className="w-5 h-5 fill-white" /> Watch Now
              </Link>
              <Link
                href={hero.media_type === "tv" ? `/tv/${hero.id}` : `/movie/${hero.id}`}
                className="flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white font-semibold px-6 py-2.5 rounded-md transition-colors backdrop-blur-sm"
              >
                <Info className="w-5 h-5" /> More Info
              </Link>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-8 mt-2 pb-20">
        {customMovies.length > 0 && (
          <div className="mb-8">
            <h2 className="text-white text-xl font-bold mb-4 flex items-center gap-2">
              <Film className="w-5 h-5 text-red-500" /> Film & Serial Khusus
            </h2>
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
              {customMovies.map((m) => <CustomMovieCard key={m.id} m={m} />)}
            </div>
          </div>
        )}
        {trending?.results    && <ContentRow title="Trending Now"      items={trending.results}      />}
        {popularMovies?.results && <ContentRow title="Popular Movies"  items={popularMovies.results} mediaType="movie" />}
        {popularTv?.results   && <ContentRow title="Popular TV Shows"  items={popularTv.results}     mediaType="tv" />}
        {topMovies?.results   && <ContentRow title="Top Rated Movies"  items={topMovies.results}     mediaType="movie" />}
        {topTv?.results       && <ContentRow title="Top Rated TV Shows" items={topTv.results}        mediaType="tv" />}
      </div>
    </div>
  );
}
