/**
 * Firebase Realtime Database REST helper.
 *
 * Security model:
 *  - Reads  → public (no auth required; Firebase rules: ".read": true)
 *  - Writes → require the Firebase DB secret, which is entered by the admin
 *             at login time and stored only in sessionStorage (never bundled).
 *
 * The write token is retrieved at call-time via getWriteToken(), so it is
 * never part of the compiled JS bundle sent to end-users.
 */

import { getWriteToken } from "@/lib/auth";
import type {
  Settings, Ad, Embed, CustomMovie,
  TmdbListResult, TmdbMovie, TmdbTvShow, TmdbSeason, TmdbFindResult,
} from "@/lib/types";

export type { Settings, Ad, Embed, CustomMovie };

const DB = "https://apps-tmdb-default-rtdb.asia-southeast1.firebasedatabase.app";

function authUrl(path: string): string {
  return `${DB}/${path}.json?auth=${getWriteToken()}`;
}

export async function fbGet<T>(path: string): Promise<T | null> {
  const r = await fetch(`${DB}/${path}.json`);
  return r.ok ? (r.json() as Promise<T>) : null;
}

export async function fbSet(path: string, data: unknown): Promise<void> {
  await fetch(authUrl(path), {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
}

export async function fbPush(path: string, data: unknown): Promise<string> {
  const r = await fetch(authUrl(path), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  const j = (await r.json()) as { name: string };
  return j.name;
}

export async function fbPatch(path: string, data: unknown): Promise<void> {
  await fetch(authUrl(path), {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
}

export async function fbDelete(path: string): Promise<void> {
  await fetch(authUrl(path), { method: "DELETE" });
}

function objToArr<T extends { id?: string }>(obj: Record<string, T> | null): T[] {
  if (!obj) return [];
  return Object.entries(obj).map(([id, v]) => ({ ...v, id }));
}

export async function hashPassword(password: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(password));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export const fb = {
  getSettings: () => fbGet<Settings>("settings"),
  setSettings: (d: Partial<Settings>) => fbSet("settings", d),

  getEmbeds:   async (): Promise<Embed[]> => objToArr(await fbGet<Record<string, Embed>>("embeds")),
  addEmbed:    (d: Omit<Embed, "id">) => fbPush("embeds", d),
  updateEmbed: (id: string, d: Partial<Embed>) => fbPatch(`embeds/${id}`, d),
  deleteEmbed: (id: string) => fbDelete(`embeds/${id}`),

  getAds:    async (): Promise<Ad[]> => objToArr(await fbGet<Record<string, Ad>>("ads")),
  addAd:     (d: Omit<Ad, "id">) => fbPush("ads", d),
  updateAd:  (id: string, d: Partial<Ad>) => fbPatch(`ads/${id}`, d),
  deleteAd:  (id: string) => fbDelete(`ads/${id}`),

  getCustomMovies:   async (): Promise<CustomMovie[]> => objToArr(await fbGet<Record<string, CustomMovie>>("custom_movies")),
  addCustomMovie:    (d: Omit<CustomMovie, "id">) => fbPush("custom_movies", d),
  updateCustomMovie: (id: string, d: Partial<CustomMovie>) => fbPatch(`custom_movies/${id}`, d),
  deleteCustomMovie: (id: string) => fbDelete(`custom_movies/${id}`),

  getPasswordHash: () => fbGet<string>("admin/passwordHash"),
  setPasswordHash: (hash: string) => fbSet("admin/passwordHash", hash),
};

export type { TmdbListResult, TmdbMovie, TmdbTvShow, TmdbSeason, TmdbFindResult };
