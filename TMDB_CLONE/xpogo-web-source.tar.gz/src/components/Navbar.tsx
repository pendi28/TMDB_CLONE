import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Search, Menu, X, Tv } from "lucide-react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [location, navigate] = useLocation();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setMenuOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-[#141414] shadow-lg" : "bg-gradient-to-b from-black/80 to-transparent"
      }`}
      style={{ marginTop: "var(--banner-top-height, 0px)" }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2">
              <Tv className="w-7 h-7 text-red-600" />
              <span className="text-2xl font-black text-red-600 tracking-tight">XpoGo</span>
            </Link>
            <div className="hidden md:flex items-center gap-6">
              <Link href="/" className="text-sm text-gray-300 hover:text-white transition-colors">Home</Link>
              <Link href="/movies" className="text-sm text-gray-300 hover:text-white transition-colors">Movies</Link>
              <Link href="/tv" className="text-sm text-gray-300 hover:text-white transition-colors">TV Shows</Link>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <form onSubmit={handleSearch} className="hidden sm:flex items-center">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-black/50 border border-white/20 text-white placeholder-gray-500 text-sm rounded-full pl-9 pr-4 py-1.5 w-48 focus:outline-none focus:border-red-600 focus:w-64 transition-all"
                />
              </div>
            </form>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden text-white p-1"
            >
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>
      {menuOpen && (
        <div className="md:hidden bg-[#141414] border-t border-white/10 px-4 py-4 space-y-3">
          <form onSubmit={handleSearch} className="flex gap-2">
            <input
              type="text"
              placeholder="Search movies & shows..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-white/10 border border-white/20 text-white placeholder-gray-500 text-sm rounded px-3 py-2 focus:outline-none focus:border-red-600"
            />
            <button type="submit" className="bg-red-600 text-white px-3 py-2 rounded text-sm">Go</button>
          </form>
          <Link href="/" onClick={() => setMenuOpen(false)} className="block text-gray-300 hover:text-white py-1">Home</Link>
          <Link href="/movies" onClick={() => setMenuOpen(false)} className="block text-gray-300 hover:text-white py-1">Movies</Link>
          <Link href="/tv" onClick={() => setMenuOpen(false)} className="block text-gray-300 hover:text-white py-1">TV Shows</Link>
        </div>
      )}
    </nav>
  );
}
