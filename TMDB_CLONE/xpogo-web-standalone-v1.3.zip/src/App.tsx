import { Router, Route, Switch, Link } from "wouter";
import { useState, useEffect } from "react";
import { fb } from "@/lib/firebase";
import HomePage from "@/pages/home";
import MoviePage from "@/pages/movie";
import TvPage from "@/pages/tv";
import SearchPage from "@/pages/search";
import AdminPage from "@/pages/admin";
import Navbar from "@/components/Navbar";

export type Settings = {
  siteName?: string;
  logo?: string;
  playerDomainAd?: string;
  footerText?: string;
};

export default function App() {
  const [settings, setSettings] = useState<Settings>({});

  useEffect(() => {
    fb.getSettings().then(s => { if (s) setSettings(s); });
  }, []);

  return (
    <Router>
      <Navbar siteName={settings.siteName || "XpoGo"} logo={settings.logo} />
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/movie/:id">{(p) => <MoviePage id={Number(p.id)} />}</Route>
        <Route path="/tv/:id">{(p) => <TvPage id={Number(p.id)} />}</Route>
        <Route path="/search" component={SearchPage} />
        <Route path="/admin" component={AdminPage} />
        <Route>
          <div style={{textAlign:"center",padding:"80px 16px"}}>
            <h2 style={{color:"#fff",fontSize:24,marginBottom:16}}>404 — Halaman tidak ditemukan</h2>
            <Link href="/" style={{color:"#00c853"}}>Kembali ke Home</Link>
          </div>
        </Route>
      </Switch>
    </Router>
  );
}
