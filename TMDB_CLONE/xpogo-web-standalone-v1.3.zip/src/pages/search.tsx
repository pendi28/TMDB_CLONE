import { useState, useEffect } from "react";
import { tmdb } from "@/lib/tmdb";
import MovieCard from "@/components/MovieCard";

export default function SearchPage() {
  const [results, setResults] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const query = params.get("q") || "";
    setQ(query);
    if (query) {
      setLoading(true);
      tmdb.search(query).then(d => { setResults(d.results || []); setLoading(false); });
    }
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    setLoading(true);
    window.history.replaceState({}, "", `/search?q=${encodeURIComponent(q.trim())}`);
    tmdb.search(q.trim()).then(d => { setResults(d.results || []); setLoading(false); });
  };

  return (
    <div style={{padding:"24px 16px 60px"}}>
      <h2 style={{fontSize:18,fontWeight:800,marginBottom:16}}>🔍 Pencarian</h2>
      <form onSubmit={handleSearch} style={{display:"flex",gap:8,marginBottom:24}}>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Cari film, serial..." style={{flex:1}} />
        <button type="submit" style={{background:"#00c853",color:"#fff",border:"none",borderRadius:8,padding:"8px 18px",fontWeight:700,fontSize:13,flexShrink:0}}>Cari</button>
      </form>

      {loading && <div style={{color:"#00c853",fontSize:13}}>Mencari...</div>}

      <div style={{display:"flex",flexWrap:"wrap",gap:12}}>
        {results
          .filter(r => r.media_type !== "person")
          .map(r => (
            <MovieCard
              key={r.id} id={r.id}
              title={r.title || r.name}
              poster={r.poster_path}
              rating={r.vote_average}
              type={r.media_type === "tv" ? "tv" : "movie"}
            />
          ))
        }
      </div>

      {!loading && results.length === 0 && q && (
        <p style={{color:"#8a9bb0",fontSize:13,textAlign:"center",padding:"40px 0"}}>Tidak ada hasil untuk "{q}"</p>
      )}
    </div>
  );
}
