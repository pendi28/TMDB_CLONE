import { useState, useEffect } from "react";
import { fb, type Settings, type Embed, type Ad, type CustomMovie } from "@/lib/firebase";
import { getToken, setToken, clearToken } from "@/lib/auth";

const DB_SECRET = import.meta.env.VITE_FIREBASE_SECRET as string | undefined;
const ADMIN_HASH = import.meta.env.VITE_ADMIN_HASH as string | undefined;

async function sha256(msg: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,"0")).join("");
}

type Tab = "settings" | "ads" | "embeds" | "custom";

const btnPrimary: React.CSSProperties = {
  background:"#00c853",color:"#fff",border:"none",borderRadius:8,
  padding:"8px 16px",fontWeight:700,fontSize:13,cursor:"pointer",
};
const btnDanger: React.CSSProperties = {
  background:"#e53935",color:"#fff",border:"none",borderRadius:8,
  padding:"6px 12px",fontSize:12,fontWeight:700,cursor:"pointer",
};
const btnSecondary: React.CSSProperties = {
  background:"#1a2332",color:"#fff",border:"1px solid #2a3a4a",borderRadius:8,
  padding:"6px 14px",fontSize:12,fontWeight:700,cursor:"pointer",
};
const card: React.CSSProperties = {
  background:"#1a2332",borderRadius:12,padding:16,marginBottom:12,
};

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{marginBottom:14}}>
      <label style={{display:"block",color:"#8a9bb0",fontSize:11,fontWeight:700,marginBottom:6,textTransform:"uppercase",letterSpacing:0.5}}>{label}</label>
      {children}
    </div>
  );
}

/* ─── Login ─── */
function LoginPanel({ onLogin }: { onLogin: () => void }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setErr("");
    try {
      const hash = await sha256(pw);
      if (ADMIN_HASH && hash !== ADMIN_HASH) {
        setErr("Password salah"); return;
      }
      setToken(hash);
      onLogin();
    } finally { setLoading(false); }
  };

  return (
    <div style={{display:"flex",alignItems:"center",justifyContent:"center",minHeight:"70vh"}}>
      <form onSubmit={submit} style={{background:"#1a2332",borderRadius:16,padding:32,width:"100%",maxWidth:360}}>
        <h2 style={{fontSize:20,fontWeight:900,marginBottom:4,textAlign:"center"}}>🔐 Admin XpoGo</h2>
        <p style={{color:"#8a9bb0",fontSize:12,textAlign:"center",marginBottom:24}}>Masuk untuk mengelola konten</p>
        <Field label="Password Admin">
          <input type="password" value={pw} onChange={e => setPw(e.target.value)} placeholder="••••••••" />
        </Field>
        {err && <p style={{color:"#e53935",fontSize:12,marginBottom:12}}>{err}</p>}
        <button type="submit" style={{...btnPrimary,width:"100%",padding:"10px"}} disabled={loading}>
          {loading ? "Memverifikasi..." : "Masuk"}
        </button>
      </form>
    </div>
  );
}

/* ─── Settings Tab ─── */
function SettingsTab() {
  const [form, setForm] = useState<Settings>({});
  const [saved, setSaved] = useState(false);

  useEffect(() => { fb.getSettings().then(s => { if(s) setForm(s); }); }, []);

  const save = async () => {
    await fb.setSettings(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div>
      <h3 style={{fontSize:16,fontWeight:800,marginBottom:16}}>⚙️ Pengaturan Situs</h3>
      <div style={card}>
        <Field label="Nama Situs">
          <input value={form.siteName || ""} onChange={e => setForm({...form,siteName:e.target.value})} placeholder="XpoGo" />
        </Field>
        <Field label="URL Logo">
          <input value={form.logo || ""} onChange={e => setForm({...form,logo:e.target.value})} placeholder="https://..." />
        </Field>
        <Field label="Domain Ad Player (optional)">
          <input value={form.playerDomainAd || ""} onChange={e => setForm({...form,playerDomainAd:e.target.value})} placeholder="ads.example.com" />
        </Field>
        <Field label="Footer Text">
          <input value={form.footerText || ""} onChange={e => setForm({...form,footerText:e.target.value})} placeholder="© 2025 XpoGo" />
        </Field>
        <button onClick={save} style={btnPrimary}>{saved ? "✓ Tersimpan!" : "Simpan"}</button>
      </div>
    </div>
  );
}

/* ─── Ads Tab ─── */
function AdsTab() {
  const [ads, setAds] = useState<Ad[]>([]);
  const [form, setForm] = useState<Partial<Ad>>({ type:"banner-top", active:true });

  const load = () => fb.getAds().then(setAds);
  useEffect(() => { load(); }, []);

  const add = async () => {
    if (!form.code) return;
    await fb.addAd(form as Ad);
    setForm({ type:"banner-top", active:true, label:"", code:"" });
    load();
  };

  return (
    <div>
      <h3 style={{fontSize:16,fontWeight:800,marginBottom:16}}>📢 Iklan</h3>
      <div style={card}>
        <h4 style={{fontSize:13,fontWeight:700,marginBottom:12,color:"#c8d6e5"}}>Tambah Iklan Baru</h4>
        <Field label="Jenis">
          <select value={form.type} onChange={e => setForm({...form,type:e.target.value as Ad["type"]})}>
            <option value="banner-top">Banner Atas</option>
            <option value="banner-bottom">Banner Bawah</option>
            <option value="popunder">Popunder</option>
          </select>
        </Field>
        <Field label="Label">
          <input value={form.label || ""} onChange={e => setForm({...form,label:e.target.value})} placeholder="Nama iklan" />
        </Field>
        <Field label="Kode HTML / Script">
          <textarea value={form.code || ""} onChange={e => setForm({...form,code:e.target.value})} rows={4} placeholder="<script>...</script>" />
        </Field>
        <button onClick={add} style={btnPrimary}>+ Tambah Iklan</button>
      </div>

      {ads.map(a => (
        <div key={a.id} style={{...card,display:"flex",justifyContent:"space-between",alignItems:"center",gap:8}}>
          <div style={{flex:1,minWidth:0}}>
            <p style={{fontWeight:700,fontSize:13}}>{a.label || a.type}</p>
            <p style={{color:"#8a9bb0",fontSize:11,textTransform:"capitalize"}}>{a.type} • {a.active ? "Aktif":"Nonaktif"}</p>
          </div>
          <div style={{display:"flex",gap:8}}>
            <button onClick={() => fb.updateAd(a.id!, {active: !a.active}).then(load)} style={btnSecondary}>
              {a.active ? "Nonaktifkan":"Aktifkan"}
            </button>
            <button onClick={() => fb.deleteAd(a.id!).then(load)} style={btnDanger}>Hapus</button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ─── Embeds Tab ─── */
function EmbedsTab() {
  const [embeds, setEmbeds] = useState<Embed[]>([]);
  const [form, setForm] = useState<Partial<Embed>>({ type:"movie", active:true });
  const [search, setSearch] = useState(""); const [searchRes, setSearchRes] = useState<any[]>([]);

  const load = () => fb.getEmbeds().then(setEmbeds);
  useEffect(() => { load(); }, []);

  const doSearch = async () => {
    if (!search.trim()) return;
    const KEY = import.meta.env.VITE_TMDB_KEY;
    const r = await fetch(`https://api.themoviedb.org/3/search/multi?api_key=${KEY}&query=${encodeURIComponent(search)}&language=id-ID`);
    const d = await r.json();
    setSearchRes((d.results || []).slice(0, 8));
  };

  const pick = (item: any) => {
    setForm(f => ({
      ...f,
      title: item.title || item.name,
      tmdbId: item.id,
      type: item.media_type === "tv" ? "series" : "movie",
    }));
    setSearchRes([]);
    setSearch("");
  };

  const add = async () => {
    if (!form.url || !form.title) return;
    await fb.addEmbed(form as Embed);
    setForm({ type:"movie", active:true });
    load();
  };

  return (
    <div>
      <h3 style={{fontSize:16,fontWeight:800,marginBottom:16}}>🔗 Embed Player</h3>
      <div style={card}>
        <h4 style={{fontSize:13,fontWeight:700,marginBottom:12,color:"#c8d6e5"}}>Tambah Embed</h4>

        <Field label="Cari TMDB">
          <div style={{display:"flex",gap:8}}>
            <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key==="Enter" && doSearch()} placeholder="Judul film/serial..." />
            <button onClick={doSearch} style={btnSecondary}>Cari</button>
          </div>
        </Field>
        {searchRes.length > 0 && (
          <div style={{background:"#0d1117",borderRadius:8,marginBottom:12,maxHeight:200,overflowY:"auto"}}>
            {searchRes.map(r => (
              <div key={r.id} onClick={() => pick(r)} style={{padding:"8px 12px",cursor:"pointer",fontSize:13,borderBottom:"1px solid #1a2332",display:"flex",gap:8,alignItems:"center"}}>
                <span style={{color:"#00c853",fontSize:10}}>{r.media_type?.toUpperCase()}</span>
                <span>{r.title || r.name}</span>
                <span style={{color:"#8a9bb0",fontSize:11}}>{r.release_date?.slice(0,4) || r.first_air_date?.slice(0,4)}</span>
              </div>
            ))}
          </div>
        )}

        <Field label="Judul">
          <input value={form.title || ""} onChange={e => setForm({...form,title:e.target.value})} placeholder="Nama film/serial" />
        </Field>
        <Field label="Tipe">
          <select value={form.type} onChange={e => setForm({...form,type:e.target.value as Embed["type"]})}>
            <option value="movie">Film</option>
            <option value="series">Serial (gunakan {"{season}"} dan {"{episode}"})</option>
          </select>
        </Field>
        <Field label="URL Embed">
          <input value={form.url || ""} onChange={e => setForm({...form,url:e.target.value})} placeholder="https://zxcstream.xyz/..." />
        </Field>
        <Field label="Sub/Dub">
          <input value={form.sub || ""} onChange={e => setForm({...form,sub:e.target.value})} placeholder="SUB / DUB (opsional)" />
        </Field>
        <button onClick={add} style={btnPrimary}>+ Tambah Embed</button>
      </div>

      {embeds.map(e => (
        <div key={e.id} style={{...card,display:"flex",justifyContent:"space-between",alignItems:"center",gap:8}}>
          <div style={{flex:1,minWidth:0}}>
            <p style={{fontWeight:700,fontSize:13}}>{e.title}</p>
            <p style={{color:"#8a9bb0",fontSize:11}} className="line-clamp-1">{e.url}</p>
            <p style={{color:"#8a9bb0",fontSize:10}}>{e.type} {e.tmdbId ? `• TMDB #${e.tmdbId}`:""} {e.sub ? `• ${e.sub}`:""} • {e.active?"Aktif":"Nonaktif"}</p>
          </div>
          <div style={{display:"flex",gap:8}}>
            <button onClick={() => fb.updateEmbed(e.id!,{active:!e.active}).then(load)} style={btnSecondary}>
              {e.active?"Nonaktifkan":"Aktifkan"}
            </button>
            <button onClick={() => fb.deleteEmbed(e.id!).then(load)} style={btnDanger}>Hapus</button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ─── Custom Movies Tab ─── */
function CustomTab() {
  const [list, setList] = useState<CustomMovie[]>([]);
  const [form, setForm] = useState<Partial<CustomMovie>>({ type:"movie" });
  const [search, setSearch] = useState(""); const [searchRes, setSearchRes] = useState<any[]>([]);

  const load = () => fb.getCustomMovies().then(setList);
  useEffect(() => { load(); }, []);

  const doSearch = async () => {
    if (!search.trim()) return;
    const KEY = import.meta.env.VITE_TMDB_KEY;
    const r = await fetch(`https://api.themoviedb.org/3/search/multi?api_key=${KEY}&query=${encodeURIComponent(search)}&language=id-ID`);
    const d = await r.json();
    setSearchRes((d.results || []).slice(0, 8));
  };

  const pick = (item: any) => {
    const IMG = (p: string, s = "w500") => p ? `https://image.tmdb.org/t/p/${s}${p}` : "";
    setForm(f => ({
      ...f,
      title: item.title || item.name,
      tmdbId: item.id,
      type: item.media_type === "tv" ? "series" : "movie",
      posterUrl: IMG(item.poster_path),
      backdropUrl: IMG(item.backdrop_path,"original"),
      description: item.overview,
      year: Number((item.release_date || item.first_air_date || "0").slice(0,4)),
    }));
    setSearchRes([]);
    setSearch("");
  };

  const add = async () => {
    if (!form.title) return;
    await fb.addCustomMovie(form as CustomMovie);
    setForm({ type:"movie" });
    load();
  };

  return (
    <div>
      <h3 style={{fontSize:16,fontWeight:800,marginBottom:16}}>🎬 Film Pilihan Admin</h3>
      <div style={card}>
        <h4 style={{fontSize:13,fontWeight:700,marginBottom:12,color:"#c8d6e5"}}>Tambah Film/Series</h4>

        <Field label="Cari TMDB">
          <div style={{display:"flex",gap:8}}>
            <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key==="Enter" && doSearch()} placeholder="Judul..." />
            <button onClick={doSearch} style={btnSecondary}>Cari</button>
          </div>
        </Field>
        {searchRes.length > 0 && (
          <div style={{background:"#0d1117",borderRadius:8,marginBottom:12,maxHeight:200,overflowY:"auto"}}>
            {searchRes.map(r => (
              <div key={r.id} onClick={() => pick(r)} style={{padding:"8px 12px",cursor:"pointer",fontSize:13,borderBottom:"1px solid #1a2332",display:"flex",gap:8,alignItems:"center"}}>
                <span style={{color:"#00c853",fontSize:10}}>{r.media_type?.toUpperCase()}</span>
                <span>{r.title || r.name}</span>
              </div>
            ))}
          </div>
        )}

        <Field label="Judul"><input value={form.title || ""} onChange={e => setForm({...form,title:e.target.value})} /></Field>
        <Field label="Tipe">
          <select value={form.type} onChange={e => setForm({...form,type:e.target.value as CustomMovie["type"]})}>
            <option value="movie">Film</option>
            <option value="series">Series</option>
          </select>
        </Field>
        <Field label="Embed URL"><input value={form.embedUrl || ""} onChange={e => setForm({...form,embedUrl:e.target.value})} placeholder="https://..." /></Field>
        <Field label="Poster URL"><input value={form.posterUrl || ""} onChange={e => setForm({...form,posterUrl:e.target.value})} placeholder="https://..." /></Field>
        <button onClick={add} style={btnPrimary}>+ Tambah</button>
      </div>

      {list.map(m => (
        <div key={m.id} style={{...card,display:"flex",gap:12,alignItems:"center"}}>
          {m.posterUrl && <img src={m.posterUrl} alt={m.title} style={{width:48,height:72,objectFit:"cover",borderRadius:6,flexShrink:0}} />}
          <div style={{flex:1,minWidth:0}}>
            <p style={{fontWeight:700,fontSize:13}}>{m.title}</p>
            <p style={{color:"#8a9bb0",fontSize:11}}>{m.type} {m.year ? `• ${m.year}` : ""} {m.tmdbId ? `• TMDB #${m.tmdbId}`:""}</p>
          </div>
          <button onClick={() => fb.deleteCustomMovie(m.id!).then(load)} style={btnDanger}>Hapus</button>
        </div>
      ))}
    </div>
  );
}

/* ─── Main Admin Page ─── */
export default function AdminPage() {
  const [logged, setLogged] = useState(false);
  const [tab, setTab] = useState<Tab>("settings");

  useEffect(() => {
    if (getToken()) setLogged(true);
  }, []);

  if (!logged) return <LoginPanel onLogin={() => setLogged(true)} />;

  const tabs: { id: Tab; label: string }[] = [
    { id:"settings", label:"⚙️ Pengaturan" },
    { id:"ads",      label:"📢 Iklan" },
    { id:"embeds",   label:"🔗 Embed" },
    { id:"custom",   label:"🎬 Custom" },
  ];

  return (
    <div style={{maxWidth:700,margin:"0 auto",padding:"24px 16px 60px"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <h2 style={{fontSize:20,fontWeight:900}}>Panel Admin</h2>
        <button onClick={() => { clearToken(); setLogged(false); }} style={{...btnSecondary,color:"#e53935",borderColor:"#e53935"}}>
          Keluar
        </button>
      </div>

      <div style={{display:"flex",gap:8,marginBottom:24,overflowX:"auto",paddingBottom:4}}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            background: tab === t.id ? "#00c853" : "#1a2332",
            color:"#fff",border:"none",borderRadius:8,
            padding:"8px 14px",fontWeight:700,fontSize:12,
            flexShrink:0,cursor:"pointer",
          }}>{t.label}</button>
        ))}
      </div>

      {tab === "settings" && <SettingsTab />}
      {tab === "ads"      && <AdsTab />}
      {tab === "embeds"   && <EmbedsTab />}
      {tab === "custom"   && <CustomTab />}
    </div>
  );
}
