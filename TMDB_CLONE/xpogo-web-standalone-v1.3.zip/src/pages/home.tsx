import { useState, useEffect } from "react";
import { tmdb, IMG } from "@/lib/tmdb";
import { fb, type CustomMovie } from "@/lib/firebase";
import MovieCard from "@/components/MovieCard";
import { Link } from "wouter";

function Row({ title, items, type }: { title: string; items: any[]; type?: "movie" | "tv" }) {
  if (!items.length) return null;
  return (
    <section style={{marginBottom:32}}>
      <h3 style={{color:"#c8d6e5",fontSize:15,fontWeight:700,marginBottom:12,paddingLeft:16}}>{title}</h3>
      <div style={{display:"flex",gap:10,overflowX:"auto",padding:"0 16px",paddingBottom:8}}>
        {items.map((m: any) => (
          <MovieCard
            key={m.id} id={m.id}
            title={m.title || m.name}
            poster={m.poster_path}
            rating={m.vote_average}
            type={type || (m.media_type === "tv" ? "tv" : "movie")}
          />
        ))}
      </div>
    </section>
  );
}

function CustomRow({ items }: { items: CustomMovie[] }) {
  if (!items.length) return null;
  return (
    <section style={{marginBottom:32}}>
      <h3 style={{color:"#c8d6e5",fontSize:15,fontWeight:700,marginBottom:12,paddingLeft:16}}>Film Pilihan Admin</h3>
      <div style={{display:"flex",gap:10,overflowX:"auto",padding:"0 16px",paddingBottom:8}}>
        {items.map((m) => (
          <Link key={m.id} href={m.tmdbId ? `/movie/${m.tmdbId}` : `/movie/${m.id}`}>
            <div style={{width:110,flexShrink:0,cursor:"pointer"}}>
              <div style={{position:"relative",borderRadius:10,overflow:"hidden",aspectRatio:"2/3",background:"#1a2332",marginBottom:6}}>
                {m.posterUrl
                  ? <img src={m.posterUrl} alt={m.title} style={{width:"100%",height:"100%",objectFit:"cover"}} loading="lazy" />
                  : <div style={{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",color:"#2a3a4a",fontSize:28}}>🎬</div>
                }
                <div style={{position:"absolute",top:6,left:6,background:"rgba(13,17,23,0.85)",color:"#00c853",fontSize:10,fontWeight:800,padding:"2px 6px",borderRadius:8}}>
                  {m.type === "series" ? "Series" : "Film"}
                </div>
              </div>
              <p style={{color:"#c8d6e5",fontSize:11,lineHeight:1.3}} className="line-clamp-2">{m.title}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}

export default function HomePage() {
  const [hero, setHero] = useState<any>(null);
  const [trending, setTrending] = useState<any[]>([]);
  const [movies, setMovies] = useState<any[]>([]);
  const [tv, setTv] = useState<any[]>([]);
  const [topMovies, setTopMovies] = useState<any[]>([]);
  const [topTv, setTopTv] = useState<any[]>([]);
  const [custom, setCustom] = useState<CustomMovie[]>([]);
  const [topBanner, setTopBanner] = useState<string>("");
  const [botBanner, setBotBanner] = useState<string>("");

  useEffect(() => {
    tmdb.trending().then(d => { setTrending(d.results || []); setHero(d.results?.[0]); });
    tmdb.popularMovies().then(d => setMovies(d.results || []));
    tmdb.popularTv().then(d => setTv(d.results || []));
    tmdb.topMovies().then(d => setTopMovies(d.results || []));
    tmdb.topTv().then(d => setTopTv(d.results || []));
    fb.getCustomMovies().then(setCustom);
    fb.getAds().then(ads => {
      ads.filter(a => a.active).forEach(a => {
        if (a.type === "banner-top") setTopBanner(a.code);
        if (a.type === "banner-bottom") setBotBanner(a.code);
        if (a.type === "popunder") {
          const el = document.createElement("div");
          el.innerHTML = a.code;
          document.body.appendChild(el);
        }
      });
    });
  }, []);

  return (
    <div style={{paddingBottom:40}}>
      {topBanner && (
        <div style={{padding:"8px 16px"}} dangerouslySetInnerHTML={{ __html: topBanner }} />
      )}

      {hero && (
        <div style={{
          position:"relative",height:320,overflow:"hidden",marginBottom:24,
          background:"#0d1117",
        }}>
          {IMG(hero.backdrop_path, "original") && (
            <img
              src={IMG(hero.backdrop_path, "original")!}
              alt=""
              style={{position:"absolute",inset:0,width:"100%",height:"100%",objectFit:"cover",opacity:0.4}}
            />
          )}
          <div style={{
            position:"absolute",inset:0,
            background:"linear-gradient(to top, #0d1117 20%, transparent 70%)",
            display:"flex",flexDirection:"column",justifyContent:"flex-end",padding:20,
          }}>
            <span style={{color:"#00c853",fontSize:11,fontWeight:700,marginBottom:6,textTransform:"uppercase",letterSpacing:1}}>
              {hero.media_type === "tv" ? "Serial TV" : "Film"} • Trending
            </span>
            <h1 style={{fontSize:22,fontWeight:900,marginBottom:8,lineHeight:1.2}}>
              {hero.title || hero.name}
            </h1>
            <p style={{color:"#8a9bb0",fontSize:12,lineHeight:1.5,marginBottom:14}} className="line-clamp-2">
              {hero.overview}
            </p>
            <div style={{display:"flex",gap:10}}>
              <Link href={`/${hero.media_type === "tv" ? "tv" : "movie"}/${hero.id}`}>
                <button style={{background:"#00c853",color:"#fff",border:"none",borderRadius:8,padding:"9px 20px",fontWeight:800,fontSize:13}}>
                  ▶ Tonton
                </button>
              </Link>
              <Link href={`/${hero.media_type === "tv" ? "tv" : "movie"}/${hero.id}`}>
                <button style={{background:"rgba(255,255,255,0.1)",color:"#fff",border:"1px solid rgba(255,255,255,0.2)",borderRadius:8,padding:"9px 20px",fontWeight:700,fontSize:13}}>
                  ℹ Info
                </button>
              </Link>
            </div>
          </div>
        </div>
      )}

      <CustomRow items={custom} />
      <Row title="🔥 Trending Minggu Ini" items={trending} />
      <Row title="🎬 Film Populer" items={movies} type="movie" />
      <Row title="📺 Serial Populer" items={tv} type="tv" />
      <Row title="⭐ Film Rating Tertinggi" items={topMovies} type="movie" />
      <Row title="🏆 Serial Rating Tertinggi" items={topTv} type="tv" />

      {botBanner && (
        <div style={{padding:"8px 16px"}} dangerouslySetInnerHTML={{ __html: botBanner }} />
      )}
    </div>
  );
}
