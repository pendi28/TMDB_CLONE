import { useState, useEffect } from "react";
import { tmdb, IMG } from "@/lib/tmdb";
import { fb, type Embed } from "@/lib/firebase";
import Comments from "@/components/Comments";
import MovieCard from "@/components/MovieCard";

export default function TvPage({ id }: { id: number }) {
  const [detail, setDetail] = useState<any>(null);
  const [embeds, setEmbeds] = useState<Embed[]>([]);
  const [active, setActive] = useState<Embed | null>(null);
  const [season, setSeason] = useState(1);
  const [ep, setEp] = useState(1);
  const [tab, setTab] = useState<"info" | "comments">("info");

  useEffect(() => {
    window.scrollTo(0, 0);
    setDetail(null); setActive(null);
    tmdb.tvDetail(id).then(d => {
      setDetail(d);
      setSeason(1); setEp(1);
    });
    fb.getEmbeds().then(list => {
      const matched = list.filter(e => e.active && e.type === "series" && (!e.tmdbId || e.tmdbId === id));
      setEmbeds(matched);
      if (matched.length) setActive(matched[0]);
    });
  }, [id]);

  const buildUrl = (url: string) =>
    url.replace(/\{season\}/gi, String(season)).replace(/\{episode\}/gi, String(ep));

  if (!detail) return (
    <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"50vh"}}>
      <div style={{color:"#00c853",fontSize:14}}>Memuat...</div>
    </div>
  );

  const seasons = detail.seasons?.filter((s: any) => s.season_number > 0) || [];
  const currentSeason = detail.seasons?.find((s: any) => s.season_number === season);
  const totalEp = currentSeason?.episode_count || 1;

  return (
    <div style={{maxWidth:900,margin:"0 auto",padding:"0 0 60px"}}>
      <div style={{position:"relative",height:240,background:"#0d1117",overflow:"hidden"}}>
        {IMG(detail.backdrop_path, "original") && (
          <img src={IMG(detail.backdrop_path,"original")!} alt="" style={{width:"100%",height:"100%",objectFit:"cover",opacity:0.4}} />
        )}
        <div style={{position:"absolute",inset:0,background:"linear-gradient(to top, #0d1117 30%, transparent 70%)"}} />
      </div>

      <div style={{padding:"0 16px"}}>
        <div style={{display:"flex",gap:16,marginTop:-60,position:"relative",marginBottom:16}}>
          {IMG(detail.poster_path,"w342") && (
            <img src={IMG(detail.poster_path,"w342")!} alt={detail.name} style={{width:90,borderRadius:10,flexShrink:0,border:"2px solid #1a2332"}} />
          )}
          <div style={{paddingTop:60}}>
            <h1 style={{fontSize:20,fontWeight:900,marginBottom:4,lineHeight:1.2}}>{detail.name}</h1>
            <div style={{display:"flex",gap:8,flexWrap:"wrap",fontSize:12,color:"#8a9bb0",marginBottom:4}}>
              <span>⭐ {detail.vote_average?.toFixed(1)}</span>
              <span>•</span>
              <span>{detail.first_air_date?.slice(0,4)}</span>
              <span>•</span>
              <span>{detail.number_of_seasons} Season</span>
            </div>
            <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
              {detail.genres?.map((g: any) => (
                <span key={g.id} style={{background:"#1a2332",color:"#00c853",fontSize:10,padding:"2px 8px",borderRadius:20,fontWeight:600}}>{g.name}</span>
              ))}
            </div>
          </div>
        </div>

        <p style={{color:"#8a9bb0",fontSize:13,lineHeight:1.6,marginBottom:20}}>{detail.overview}</p>

        {active && (
          <div style={{marginBottom:16}}>
            {seasons.length > 1 && (
              <div style={{display:"flex",gap:8,marginBottom:10,overflowX:"auto",paddingBottom:4}}>
                {seasons.map((s: any) => (
                  <button key={s.season_number} onClick={() => { setSeason(s.season_number); setEp(1); }} style={{
                    background: season === s.season_number ? "#00c853" : "#1a2332",
                    color:"#fff",border:"none",borderRadius:8,padding:"6px 14px",fontSize:12,fontWeight:700,flexShrink:0,
                  }}>S{s.season_number}</button>
                ))}
              </div>
            )}
            <div style={{display:"flex",gap:8,marginBottom:10,overflowX:"auto",paddingBottom:4}}>
              {Array.from({length:totalEp},(_,i)=>i+1).map(n => (
                <button key={n} onClick={() => setEp(n)} style={{
                  background: ep === n ? "#00c853" : "#1a2332",
                  color:"#fff",border:"none",borderRadius:8,padding:"6px 12px",fontSize:12,fontWeight:700,flexShrink:0,
                }}>Ep {n}</button>
              ))}
            </div>

            <div style={{position:"relative",paddingTop:"56.25%",borderRadius:12,overflow:"hidden",background:"#000"}}>
              <iframe
                key={`${active.url}-${season}-${ep}`}
                src={buildUrl(active.url)}
                style={{position:"absolute",inset:0,width:"100%",height:"100%",border:"none"}}
                allowFullScreen allow="autoplay; encrypted-media; fullscreen"
              />
            </div>

            {embeds.length > 1 && (
              <div style={{display:"flex",gap:8,marginTop:10,flexWrap:"wrap"}}>
                {embeds.map((e, i) => (
                  <button key={e.id} onClick={() => setActive(e)} style={{
                    background: active?.id === e.id ? "#00c853" : "#1a2332",
                    color:"#fff",border:"none",borderRadius:8,padding:"6px 14px",fontSize:12,fontWeight:700,
                  }}>Server {i + 1}{e.sub ? ` [${e.sub}]` : ""}</button>
                ))}
              </div>
            )}
          </div>
        )}

        <div style={{display:"flex",gap:8,marginBottom:20}}>
          {["info","comments"].map(t => (
            <button key={t} onClick={() => setTab(t as any)} style={{
              background: tab === t ? "#00c853" : "#1a2332",
              color:"#fff",border:"none",borderRadius:8,
              padding:"8px 18px",fontWeight:700,fontSize:13,
            }}>{t === "info" ? "Info" : "💬 Komentar"}</button>
          ))}
        </div>

        {tab === "info" && detail.credits?.cast?.length > 0 && (
          <div style={{marginBottom:24}}>
            <h3 style={{fontSize:14,fontWeight:700,marginBottom:10,color:"#c8d6e5"}}>Pemeran</h3>
            <div style={{display:"flex",gap:10,overflowX:"auto",paddingBottom:8}}>
              {detail.credits.cast.slice(0,10).map((c: any) => (
                <div key={c.id} style={{flexShrink:0,width:72,textAlign:"center"}}>
                  <div style={{width:72,height:72,borderRadius:"50%",overflow:"hidden",background:"#1a2332",marginBottom:4}}>
                    {c.profile_path
                      ? <img src={IMG(c.profile_path,"w185")!} alt={c.name} style={{width:"100%",height:"100%",objectFit:"cover"}} />
                      : <div style={{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24}}>👤</div>
                    }
                  </div>
                  <p style={{fontSize:10,color:"#c8d6e5",lineHeight:1.2}} className="line-clamp-2">{c.name}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "info" && detail.similar?.results?.length > 0 && (
          <div>
            <h3 style={{fontSize:14,fontWeight:700,marginBottom:10,color:"#c8d6e5"}}>Serial Serupa</h3>
            <div style={{display:"flex",gap:10,overflowX:"auto",paddingBottom:8}}>
              {detail.similar.results.slice(0,10).map((m: any) => (
                <MovieCard key={m.id} id={m.id} title={m.name} poster={m.poster_path} rating={m.vote_average} type="tv" />
              ))}
            </div>
          </div>
        )}

        {tab === "comments" && <Comments mediaType="tv" tmdbId={id} />}
      </div>
    </div>
  );
}
