const KEY = "xpogo_admin_token";
export const getToken = () => sessionStorage.getItem(KEY);
export const setToken = (t: string) => sessionStorage.setItem(KEY, t);
export const clearToken = () => sessionStorage.removeItem(KEY);
export const isLoggedIn = () => !!getToken();
