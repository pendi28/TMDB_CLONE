const KEY = import.meta.env.VITE_TMDB_KEY as string;
const BASE = "https://api.themoviedb.org/3";
export const IMG = (p: string | null | undefined, size = "w500") =>
  p ? `https://image.tmdb.org/t/p/${size}${p}` : null;

async function get<T>(path: string, params: Record<string, string | number> = {}): Promise<T> {
  const url = new URL(BASE + path);
  url.searchParams.set("api_key", KEY);
  url.searchParams.set("language", "id-ID");
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, String(v)));
  const r = await fetch(url.toString());
  if (!r.ok) throw new Error(`TMDB ${r.status}`);
  return r.json();
}

export const tmdb = {
  trending: (type = "all", window = "week", page = 1) => get<any>(`/trending/${type}/${window}`, { page }),
  popularMovies: (page = 1) => get<any>("/movie/popular", { page }),
  popularTv: (page = 1) => get<any>("/tv/popular", { page }),
  topMovies: (page = 1) => get<any>("/movie/top_rated", { page }),
  topTv: (page = 1) => get<any>("/tv/top_rated", { page }),
  movieDetail: (id: number) => get<any>(`/movie/${id}`, { append_to_response: "credits,similar,videos" }),
  tvDetail: (id: number) => get<any>(`/tv/${id}`, { append_to_response: "credits,similar,videos" }),
  search: (query: string, page = 1) => get<any>("/search/multi", { query, page }),
  genres: (type: "movie" | "tv") => get<any>(`/genre/${type}/list`),
};
