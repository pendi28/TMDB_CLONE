const DB = "https://apps-tmdb-default-rtdb.asia-southeast1.firebasedatabase.app";
const SECRET = import.meta.env.VITE_FIREBASE_SECRET as string | undefined;

async function dbGet<T>(path: string): Promise<T | null> {
  const r = await fetch(`${DB}/${path}.json`);
  if (!r.ok) return null;
  return r.json();
}

async function dbSet(path: string, data: unknown): Promise<void> {
  await fetch(`${DB}/${path}.json?auth=${SECRET}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
}

async function dbPush(path: string, data: unknown): Promise<string> {
  const r = await fetch(`${DB}/${path}.json?auth=${SECRET}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  const j = await r.json();
  return j.name as string;
}

async function dbPatch(path: string, data: unknown): Promise<void> {
  await fetch(`${DB}/${path}.json?auth=${SECRET}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
}

async function dbDelete(path: string): Promise<void> {
  await fetch(`${DB}/${path}.json?auth=${SECRET}`, { method: "DELETE" });
}

export type Settings = {
  siteName?: string;
  logo?: string;
  playerDomainAd?: string;
  footerText?: string;
};

export type Embed = {
  id?: string;
  title: string;
  url: string;
  type: "movie" | "series";
  active: boolean;
  tmdbId?: number;
  sub?: string;
};

export type Ad = {
  id?: string;
  type: "banner-top" | "banner-bottom" | "popunder";
  label: string;
  code: string;
  active: boolean;
};

export type CustomMovie = {
  id?: string;
  title: string;
  posterUrl?: string;
  backdropUrl?: string;
  description?: string;
  year?: number;
  genres?: string[];
  embedUrl: string;
  type: "movie" | "series";
  tmdbId?: number;
};

export type Comment = {
  id?: string;
  name: string;
  text: string;
  likes: number;
  createdAt: number;
  replies?: Record<string, { name: string; text: string; createdAt: number }>;
};

function objToArr<T extends { id?: string }>(obj: Record<string, T> | null): T[] {
  if (!obj) return [];
  return Object.entries(obj).map(([id, v]) => ({ ...v, id }));
}

export const fb = {
  getSettings: () => dbGet<Settings>("settings"),
  setSettings: (d: Settings) => dbSet("settings", d),

  getEmbeds: async (): Promise<Embed[]> => objToArr(await dbGet<Record<string, Embed>>("embeds")),
  addEmbed: (d: Embed) => dbPush("embeds", d),
  updateEmbed: (id: string, d: Partial<Embed>) => dbPatch(`embeds/${id}`, d),
  deleteEmbed: (id: string) => dbDelete(`embeds/${id}`),

  getAds: async (): Promise<Ad[]> => objToArr(await dbGet<Record<string, Ad>>("ads")),
  addAd: (d: Ad) => dbPush("ads", d),
  updateAd: (id: string, d: Partial<Ad>) => dbPatch(`ads/${id}`, d),
  deleteAd: (id: string) => dbDelete(`ads/${id}`),

  getCustomMovies: async (): Promise<CustomMovie[]> => objToArr(await dbGet<Record<string, CustomMovie>>("custom_movies")),
  addCustomMovie: (d: CustomMovie) => dbPush("custom_movies", d),
  deleteCustomMovie: (id: string) => dbDelete(`custom_movies/${id}`),

  getComments: async (mediaType: string, tmdbId: number): Promise<Comment[]> => {
    const path = `comments/${mediaType}_${tmdbId}`;
    return objToArr(await dbGet<Record<string, Comment>>(path));
  },
  addComment: (mediaType: string, tmdbId: number, d: Omit<Comment, "id">) =>
    dbPush(`comments/${mediaType}_${tmdbId}`, d),
  likeComment: async (mediaType: string, tmdbId: number, commentId: string, current: number) =>
    dbPatch(`comments/${mediaType}_${tmdbId}/${commentId}`, { likes: current + 1 }),
  addReply: (mediaType: string, tmdbId: number, commentId: string, d: { name: string; text: string; createdAt: number }) =>
    dbPush(`comments/${mediaType}_${tmdbId}/${commentId}/replies`, d),
};
