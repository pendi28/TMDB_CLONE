import { Link } from "wouter";
import { IMG } from "@/lib/tmdb";

interface Props {
  id: number;
  title: string;
  poster?: string | null;
  rating?: number;
  type?: "movie" | "tv";
}

export default function MovieCard({ id, title, poster, rating, type = "movie" }: Props) {
  const href = `/${type === "tv" ? "tv" : "movie"}/${id}`;
  const src = IMG(poster, "w342");
  return (
    <Link href={href}>
      <div style={{width:110,flexShrink:0,cursor:"pointer"}}>
        <div style={{position:"relative",borderRadius:10,overflow:"hidden",aspectRatio:"2/3",background:"#1a2332",marginBottom:6}}>
          {src
            ? <img src={src} alt={title} style={{width:"100%",height:"100%",objectFit:"cover"}} loading="lazy" />
            : <div style={{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",color:"#2a3a4a",fontSize:28}}>🎬</div>
          }
          {rating != null && (
            <div style={{
              position:"absolute",top:6,left:6,
              background:"rgba(13,17,23,0.85)",
              color:"#f59e0b",fontSize:10,fontWeight:800,
              padding:"2px 6px",borderRadius:8,border:"1px solid #f59e0b",
            }}>{Math.round(rating * 10)}%</div>
          )}
        </div>
        <p style={{color:"#c8d6e5",fontSize:11,lineHeight:1.3}} className="line-clamp-2">{title}</p>
      </div>
    </Link>
  );
}
