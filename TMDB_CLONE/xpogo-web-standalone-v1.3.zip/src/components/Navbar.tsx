import { useState } from "react";
import { Link, useLocation } from "wouter";

export default function Navbar({ siteName, logo }: { siteName: string; logo?: string }) {
  const [location] = useLocation();
  const [q, setQ] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (q.trim()) window.location.href = `/search?q=${encodeURIComponent(q.trim())}`;
  };

  return (
    <nav style={{
      position:"sticky",top:0,zIndex:100,
      background:"rgba(13,17,23,0.95)",backdropFilter:"blur(12px)",
      borderBottom:"1px solid #1a2332",
      display:"flex",alignItems:"center",gap:12,
      padding:"12px 16px",
    }}>
      <Link href="/" style={{fontWeight:900,fontSize:20,color:"#00c853",letterSpacing:-0.5,flexShrink:0}}>
        {logo ? <img src={logo} alt={siteName} style={{height:28}} /> : siteName}
      </Link>
      <form onSubmit={handleSearch} style={{flex:1,display:"flex",gap:8,maxWidth:400}}>
        <input
          value={q} onChange={e => setQ(e.target.value)}
          placeholder="Cari film, serial..."
          style={{flex:1,padding:"7px 12px",fontSize:13}}
        />
        <button type="submit" style={{
          background:"#00c853",color:"#fff",border:"none",
          borderRadius:8,padding:"7px 14px",fontWeight:700,fontSize:13,
        }}>Cari</button>
      </form>
      <Link href="/admin" style={{
        color: location === "/admin" ? "#00c853" : "#8a9bb0",
        fontSize:13,fontWeight:600,flexShrink:0,
      }}>Admin</Link>
    </nav>
  );
}
