import { useState, useEffect } from "react";
import { fb, type Comment } from "@/lib/firebase";

export default function Comments({ mediaType, tmdbId }: { mediaType: string; tmdbId: number }) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [reply, setReply] = useState<{ id: string; name: string; text: string } | null>(null);
  const [loading, setLoading] = useState(false);

  const load = () => fb.getComments(mediaType, tmdbId).then(c => setComments(c.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))));
  useEffect(() => { load(); }, [mediaType, tmdbId]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !text.trim()) return;
    setLoading(true);
    try {
      if (reply) {
        await fb.addReply(mediaType, tmdbId, reply.id, { name, text, createdAt: Date.now() });
        setReply(null);
      } else {
        await fb.addComment(mediaType, tmdbId, { name, text, likes: 0, createdAt: Date.now() });
      }
      setText("");
      await load();
    } finally { setLoading(false); }
  };

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleDateString("id-ID", { day:"numeric", month:"short", year:"numeric" });
  };

  return (
    <div style={{marginTop:32}}>
      <h3 style={{fontSize:16,fontWeight:700,marginBottom:16,color:"#c8d6e5"}}>💬 Komentar ({comments.length})</h3>

      <form onSubmit={submit} style={{marginBottom:24,background:"#1a2332",borderRadius:12,padding:16}}>
        {reply && (
          <div style={{
            background:"rgba(0,200,83,0.1)",border:"1px solid #00c853",
            borderRadius:8,padding:"8px 12px",marginBottom:12,fontSize:12,color:"#00c853",
            display:"flex",justifyContent:"space-between",alignItems:"center",
          }}>
            <span>Membalas komentar...</span>
            <button type="button" onClick={() => setReply(null)} style={{background:"none",border:"none",color:"#00c853",fontSize:16}}>✕</button>
          </div>
        )}
        <div style={{display:"flex",gap:8,marginBottom:8}}>
          <input value={name} onChange={e => setName(e.target.value)} placeholder="Nama kamu" style={{flex:1}} />
        </div>
        <textarea
          value={text} onChange={e => setText(e.target.value)}
          placeholder={reply ? "Tulis balasan..." : "Tulis komentar..."}
          rows={3} style={{marginBottom:8,resize:"vertical"}}
        />
        <button type="submit" disabled={loading} style={{
          background:"#00c853",color:"#fff",border:"none",borderRadius:8,
          padding:"8px 20px",fontWeight:700,fontSize:13,
          opacity: loading ? 0.6 : 1,
        }}>{loading ? "Mengirim..." : reply ? "Balas" : "Kirim Komentar"}</button>
      </form>

      <div style={{display:"flex",flexDirection:"column",gap:12}}>
        {comments.map(c => (
          <div key={c.id} style={{background:"#1a2332",borderRadius:12,padding:16}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
              <span style={{fontWeight:700,fontSize:13,color:"#fff"}}>{c.name}</span>
              <span style={{fontSize:11,color:"#8a9bb0"}}>{formatDate(c.createdAt)}</span>
            </div>
            <p style={{fontSize:13,color:"#c8d6e5",lineHeight:1.5,marginBottom:10}}>{c.text}</p>
            <div style={{display:"flex",gap:12}}>
              <button
                onClick={() => fb.likeComment(mediaType, tmdbId, c.id!, c.likes).then(load)}
                style={{background:"none",border:"none",color:"#8a9bb0",fontSize:12,display:"flex",alignItems:"center",gap:4}}
              >👍 {c.likes}</button>
              <button
                onClick={() => setReply({ id: c.id!, name: "", text: "" })}
                style={{background:"none",border:"none",color:"#8a9bb0",fontSize:12}}
              >↩ Balas</button>
            </div>
            {c.replies && Object.entries(c.replies).map(([rid, r]) => (
              <div key={rid} style={{marginTop:8,marginLeft:16,padding:"10px 12px",background:"rgba(0,200,83,0.05)",borderRadius:8,borderLeft:"2px solid #00c853"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <span style={{fontWeight:700,fontSize:12,color:"#fff"}}>{r.name}</span>
                  <span style={{fontSize:11,color:"#8a9bb0"}}>{formatDate(r.createdAt)}</span>
                </div>
                <p style={{fontSize:12,color:"#c8d6e5",lineHeight:1.4}}>{r.text}</p>
              </div>
            ))}
          </div>
        ))}
        {comments.length === 0 && (
          <p style={{color:"#8a9bb0",fontSize:13,textAlign:"center",padding:"20px 0"}}>Belum ada komentar. Jadilah yang pertama!</p>
        )}
      </div>
    </div>
  );
}
